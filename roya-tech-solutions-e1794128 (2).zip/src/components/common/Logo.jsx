import React from 'react';
import { motion } from 'framer-motion';

export default function Logo() {
  const logoUrl = 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/da80a3cfc_WhatsAppImage2025-07-17at212526.png';

  return (
    <motion.div
      className="flex items-center cursor-pointer"
      whileHover={{ scale: 1.05 }}
      transition={{ type: 'spring', stiffness: 300 }}
    >
      <img src={logoUrl} alt="ROYA Tech Logo" className="h-16 object-contain" />
    </motion.div>
  );
}