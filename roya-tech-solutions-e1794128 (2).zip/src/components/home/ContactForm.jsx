
import React, { useState } from "react";
import { Contact as ContactEntity } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Send, CheckCircle, Sparkles, Zap, Phone, Mail, MapPin } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function ContactForm() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [focusedField, setFocusedField] = useState(null);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData((prev) => ({ ...prev, [id]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;
    setIsSubmitting(true);

    try {
      await ContactEntity.create(formData);
      setIsSubmitted(true);
      setFormData({ name: "", email: "", message: "" });
    } catch (error) {
      console.error("Failed to submit contact form", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 40, scale: 0.95 },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        duration: 0.8,
        ease: "easeOut"
      }
    }
  };

  const inputVariants = {
    hidden: { opacity: 0, x: -30 },
    visible: {
      opacity: 1,
      x: 0,
      transition: { duration: 0.6, ease: "easeOut" }
    }
  };

  if (isSubmitted) {
    return (
      <section className="py-24 relative overflow-hidden">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            className="attractive-card p-16 shadow-2xl border-0 relative overflow-hidden"
            initial={{ opacity: 0, scale: 0.8, rotate: -5 }}
            animate={{ opacity: 1, scale: 1, rotate: 0 }}
            transition={{ duration: 0.6, type: "spring", stiffness: 100 }}>

            <div className="absolute inset-0 bg-gradient-to-br from-green-400/10 via-blue-400/10 to-indigo-400/10"></div>
            
            <motion.div
              animate={{
                rotate: 360,
                scale: [1, 1.2, 1]
              }}
              transition={{
                rotate: { duration: 2, ease: "easeInOut" },
                scale: { duration: 1, repeat: Infinity, repeatType: "reverse" }
              }}
              className="relative z-10">

              <CheckCircle className="h-20 w-20 text-green-500 mx-auto mb-8" />
            </motion.div>
            
            <motion.h3
              className="text-4xl font-bold text-slate-900 mb-6 relative z-10"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}>

              Message Sent Successfully!
            </motion.h3>
            
            <motion.p
              className="text-slate-700 text-xl mb-10 relative z-10"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.6 }}>

              Thank you for reaching out. We will get back to you within 24 hours with a comprehensive response.
            </motion.p>
            
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}>

              <Button
                onClick={() => setIsSubmitted(false)}
                className="gradient-primary text-white hover:shadow-lg transition-all duration-300 relative z-10 px-8 py-4 text-lg rounded-xl">

                Send Another Message
                <motion.div
                  animate={{ rotate: [0, 360] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  className="ml-3">

                  <Sparkles className="h-5 w-5" />
                </motion.div>
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </section>);

  }

  return (
    <section className="py-24 relative overflow-hidden bg-gradient-to-r from-slate-100 via-blue-50 to-indigo-50">
      {/* Floating Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(8)].map((_, i) =>
        <motion.div
          key={i}
          className="absolute w-3 h-3 bg-blue-500/20 rounded-full"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`
          }}
          animate={{
            y: [0, -50, 0],
            opacity: [0, 1, 0],
            scale: [1, 1.5, 1]
          }}
          transition={{
            duration: 4 + Math.random() * 2,
            repeat: Infinity,
            delay: Math.random() * 2,
            ease: "easeInOut"
          }} />

        )}
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}>

          <motion.div className="text-center mb-20" variants={cardVariants}>
            <div className="inline-flex items-center px-6 py-3 bg-blue-100 text-blue-700 rounded-full font-semibold text-lg mb-8">
              Get in Touch
            </div>
            <h2 className="text-4xl md:text-6xl font-bold text-slate-900 mb-6">Let's Start Building</h2>
            <p className="text-xl text-slate-700 max-w-4xl mx-auto leading-relaxed">
              Have a project in mind or just want to say hello? Drop us a line and let's create something amazing together.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
            {/* Contact Info */}
            <motion.div variants={cardVariants} className="lg:col-span-1">
              <div className="space-y-8">
                <motion.div className="attractive-card p-8 attractive-lift border-0 shadow-lg text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl">
                    <Phone className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-4">Call Us</h3>
                  <p className="text-slate-700 text-lg">+1 (916) 465-1850</p>
                </motion.div>

                <motion.div className="attractive-card p-8 attractive-lift border-0 shadow-lg text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl">
                    <Mail className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-4">Email Us</h3>
                  <p className="text-slate-700 text-lg">info@royatech.com</p>
                </motion.div>

                <motion.div className="attractive-card p-8 attractive-lift border-0 shadow-lg text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl">
                    <MapPin className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-4">Visit Us</h3>
                  <p className="text-slate-700 text-lg">1201 Fulton Ave<br />Sacramento, CA 95825</p>
                </motion.div>
              </div>
            </motion.div>

            {/* Contact Form */}
            <motion.div variants={cardVariants} className="lg:col-span-2">
              <motion.form
                onSubmit={handleSubmit} className="my-32 px-10 py-12 attractive-card space-y-8 shadow-xl border-0 relative overflow-hidden">


                <div className="absolute inset-0 bg-gradient-to-br from-blue-600/5 via-indigo-600/5 to-purple-600/5"></div>
                
                <div className="relative z-10">
                  <motion.div
                    className="relative"
                    variants={inputVariants}>

                    <motion.div
                      className={`absolute -inset-1 bg-gradient-to-r from-blue-400 to-indigo-500 rounded-xl blur opacity-0 transition-opacity duration-300 ${
                      focusedField === 'name' ? 'opacity-75' : ''}`
                      } />

                    <Input
                      id="name"
                      type="text"
                      placeholder="Your Name"
                      value={formData.name}
                      onChange={handleInputChange}
                      onFocus={() => setFocusedField('name')}
                      onBlur={() => setFocusedField(null)}
                      required
                      className="bg-white/90 border-slate-300 text-slate-900 placeholder:text-slate-500 h-14 text-lg transition-all duration-300 relative z-10 rounded-xl" />

                    <AnimatePresence>
                      {focusedField === 'name' &&
                      <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.8 }}
                        className="absolute right-4 top-1/2 -translate-y-1/2">

                          <Sparkles className="h-5 w-5 text-blue-500" />
                        </motion.div>
                      }
                    </AnimatePresence>
                  </motion.div>

                  <motion.div
                    className="relative"
                    variants={inputVariants}>

                    <motion.div
                      className={`absolute -inset-1 bg-gradient-to-r from-blue-400 to-indigo-500 rounded-xl blur opacity-0 transition-opacity duration-300 ${
                      focusedField === 'email' ? 'opacity-75' : ''}`
                      } />

                    <Input
                      id="email"
                      type="email"
                      placeholder="Your Email"
                      value={formData.email}
                      onChange={handleInputChange}
                      onFocus={() => setFocusedField('email')}
                      onBlur={() => setFocusedField(null)}
                      required className="bg-white/90 text-slate-900 my-2 px-3 py-2 text-lg flex w-full border ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm border-slate-300 placeholder:text-slate-500 h-14 transition-all duration-300 relative z-10 rounded-xl" />


                    <AnimatePresence>
                      {focusedField === 'email' &&
                      <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.8 }}
                        className="absolute right-4 top-1/2 -translate-y-1/2">

                          <Zap className="h-5 w-5 text-blue-500" />
                        </motion.div>
                      }
                    </AnimatePresence>
                  </motion.div>

                  <motion.div
                    className="relative"
                    variants={inputVariants}>

                    <motion.div
                      className={`absolute -inset-1 bg-gradient-to-r from-blue-400 to-indigo-500 rounded-xl blur opacity-0 transition-opacity duration-300 ${
                      focusedField === 'message' ? 'opacity-75' : ''}`
                      } />

                    <Textarea
                      id="message"
                      placeholder="Your Message"
                      value={formData.message}
                      onChange={handleInputChange}
                      onFocus={() => setFocusedField('message')}
                      onBlur={() => setFocusedField(null)}
                      required
                      className="bg-white/90 border-slate-300 text-slate-900 placeholder:text-slate-500 min-h-[180px] text-lg transition-all duration-300 relative z-10 rounded-xl" />

                    <AnimatePresence>
                      {focusedField === 'message' &&
                      <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.8 }}
                        className="absolute right-4 top-4">

                          <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}>

                            <Sparkles className="h-5 w-5 text-blue-500" />
                          </motion.div>
                        </motion.div>
                      }
                    </AnimatePresence>
                  </motion.div>

                  <motion.div
                    className="text-center"
                    whileHover={{ scale: 1.02 }}>

                    <motion.div
                      whileHover={{ scale: 1.05, rotate: [0, -1, 1, 0] }}
                      whileTap={{ scale: 0.95 }}
                      transition={{ type: "spring", stiffness: 300 }}>

                      <Button
                        type="submit"
                        disabled={isSubmitting}
                        size="lg" className="bg-primary text-white my-5 px-12 py-6 text-xl font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 hover:bg-primary/90 h-11 gradient-primary hover:shadow-2xl transition-all duration-300 hover:scale-105 rounded-2xl relative overflow-hidden group">


                        <motion.div
                          className="absolute inset-0 bg-white/10 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left" />

                        <span className="relative z-10 flex items-center">
                          {isSubmitting ?
                          <>
                              <motion.div
                              animate={{ rotate: 360 }}
                              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                              className="mr-3">

                                <div className="w-6 h-6 border-3 border-white/30 border-t-white rounded-full" />
                              </motion.div>
                              Sending...
                            </> :

                          <>
                              Send Message
                              <motion.div
                              animate={{ x: [0, 5, 0] }}
                              transition={{ duration: 1.5, repeat: Infinity }}
                              className="ml-3">

                                <Send className="h-6 w-6" />
                              </motion.div>
                            </>
                          }
                        </span>
                      </Button>
                    </motion.div>
                  </motion.div>
                </div>
              </motion.form>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>);

}
