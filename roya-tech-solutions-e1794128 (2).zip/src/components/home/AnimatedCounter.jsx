import React, { useEffect, useRef } from 'react';
import { motion, useInView, useMotionValue, useTransform, animate } from 'framer-motion';

export default function AnimatedCounter({ to, isPercentage = false }) {
  const count = useMotionValue(0);
  
  // For integers, round. For floats, format to one decimal place.
  const rounded = useTransform(count, (latest) => {
    if (isPercentage) {
      return latest.toFixed(1);
    }
    return Math.round(latest);
  });

  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  useEffect(() => {
    if (isInView) {
      const animation = animate(count, to, {
        duration: 2,
        ease: 'easeOut',
      });
      return () => animation.stop();
    }
  }, [isInView, to, count]);

  return <motion.span ref={ref}>{rounded}</motion.span>;
}