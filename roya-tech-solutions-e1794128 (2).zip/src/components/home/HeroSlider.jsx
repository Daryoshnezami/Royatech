import React, { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";

const slides = [
  {
    image: "https://images.unsplash.com/photo-1604398194220-9721115e2a22?q=80&w=2000&auto=format&fit=crop",
    title: "Engineering the Future",
    description: "We build beautiful, scalable, and powerful digital experiences that define tomorrow.",
  },
  {
    image: "https://images.unsplash.com/photo-1521737711867-e3b97375f902?q=80&w=2000&auto=format&fit=crop",
    title: "Innovation Through Collaboration",
    description: "Your vision, our expertise. Together, we create technology that inspires and transforms.",
  },
  {
    image: "https://images.unsplash.com/photo-1554679611-b39b654e8364?q=80&w=2000&auto=format&fit=crop",
    title: "Unleash Your Digital Potential",
    description: "From complex applications to seamless infrastructure, we deliver solutions that drive success.",
  },
];

const variants = {
  enter: (direction) => ({
    x: direction > 0 ? 1000 : -1000,
    opacity: 0,
  }),
  center: {
    zIndex: 1,
    x: 0,
    opacity: 1,
  },
  exit: (direction) => ({
    zIndex: 0,
    x: direction < 0 ? 1000 : -1000,
    opacity: 0,
  }),
};

export default function HeroSlider() {
  const [[page, direction], setPage] = useState([0, 0]);

  const paginate = (newDirection) => {
    setPage([(page + newDirection + slides.length) % slides.length, newDirection]);
  };

  const wrapPaginate = useCallback(() => {
    paginate(1);
  }, [page]);

  useEffect(() => {
    const timer = setTimeout(wrapPaginate, 5000);
    return () => clearTimeout(timer);
  }, [page, wrapPaginate]);

  return (
    <div className="relative w-full h-[600px] md:h-[700px] flex items-center justify-center overflow-hidden">
      <AnimatePresence initial={false} custom={direction}>
        <motion.div
          key={page}
          custom={direction}
          variants={variants}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{
            x: { type: "spring", stiffness: 300, damping: 30 },
            opacity: { duration: 0.2 },
          }}
          className="absolute w-full h-full"
        >
          <img
            src={slides[page].image}
            alt={slides[page].title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/60" />
        </motion.div>
      </AnimatePresence>

      <div className="relative z-10 text-center text-white p-8">
        <motion.h1 
          key={`${page}-title`}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3, ease: "easeOut" }}
          className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight drop-shadow-lg"
        >
          {slides[page].title}
        </motion.h1>
        <motion.p 
          key={`${page}-desc`}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5, ease: "easeOut" }}
          className="text-lg md:text-xl text-slate-200 mb-10 max-w-3xl mx-auto drop-shadow-md"
        >
          {slides[page].description}
        </motion.p>
        <motion.div
          key={`${page}-button`}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.7, ease: "easeOut" }}
        >
          <Link to={createPageUrl("Contact")}>
            <Button size="lg" className="gradient-accent-bg text-white hover:shadow-xl transition-all duration-300 hover:scale-105">
              Start Your Project
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </motion.div>
      </div>

      <div className="absolute z-20 top-1/2 -translate-y-1/2 left-4 md:left-8">
        <button
          onClick={() => paginate(-1)}
          className="bg-white/20 hover:bg-white/40 text-white p-2 rounded-full transition-colors"
        >
          <ChevronLeft className="h-6 w-6" />
        </button>
      </div>
      <div className="absolute z-20 top-1/2 -translate-y-1/2 right-4 md:right-8">
        <button
          onClick={() => paginate(1)}
          className="bg-white/20 hover:bg-white/40 text-white p-2 rounded-full transition-colors"
        >
          <ChevronRight className="h-6 w-6" />
        </button>
      </div>

      <div className="absolute z-20 bottom-8 left-1/2 -translate-x-1/2 flex space-x-2">
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => setPage([i, i > page ? 1 : -1])}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              i === page ? 'bg-white scale-125' : 'bg-white/50 hover:bg-white/80'
            }`}
          />
        ))}
      </div>
    </div>
  );
}