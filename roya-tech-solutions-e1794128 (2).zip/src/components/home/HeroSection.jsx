
import React from "react";
import { motion } from "framer-motion";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight, Play, Star, Shield, Zap, Award } from "lucide-react";

export default function HeroSection() {
  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.3
      }
    }
  };

  const slideFromLeft = {
    hidden: { x: -100, opacity: 0 },
    visible: {
      x: 0,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 20,
        duration: 1.2
      }
    }
  };

  const slideFromRight = {
    hidden: { x: 100, opacity: 0 },
    visible: {
      x: 0,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 20,
        duration: 1.2
      }
    }
  };

  const fadeInUp = {
    hidden: { y: 60, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 1,
        ease: "easeOut"
      }
    }
  };

  // Enhanced Professional Service-based Slideshow Images
  const serviceSlides = [
  {
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/1bdf16150_image.png",
    title: "Revolutionary Web Development",
    subtitle: "Building next-generation websites and applications with cutting-edge technology, stunning design, and lightning-fast performance.",
    service: "Web Development",
    features: ["React & Next.js", "Custom Design", "SEO Optimized"],
    gradient: "from-blue-600 via-indigo-600 to-purple-600"
  },
  {
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/240a95a43_image.png",
    title: "Advanced Cybersecurity Solutions",
    subtitle: "Comprehensive digital protection with enterprise-grade security, 24/7 monitoring, and proactive threat prevention.",
    service: "Cybersecurity",
    features: ["Threat Prevention", "24/7 Monitoring", "Compliance Ready"],
    gradient: "from-red-600 via-orange-600 to-yellow-600"
  },
  {
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/3797d1628_image.png",
    title: "Scalable Cloud Infrastructure",
    subtitle: "Future-ready cloud solutions with auto-scaling, disaster recovery, and optimized performance for global reach.",
    service: "Cloud Solutions",
    features: ["Auto Scaling", "Global CDN", "99.9% Uptime"],
    gradient: "from-cyan-600 via-blue-600 to-indigo-600"
  },
  {
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=4000&auto=format&fit=crop",
    title: "Native Mobile Applications",
    subtitle: "Cross-platform mobile apps with native performance, intuitive design, and seamless user experiences.",
    service: "App Development",
    features: ["iOS & Android", "Native Performance", "App Store Ready"],
    gradient: "from-purple-600 via-pink-600 to-rose-600"
  },
  {
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/db073ac9c_image.png",
    title: "Enterprise Network Solutions",
    subtitle: "Professional network infrastructure with advanced security, seamless connectivity, and 24/7 expert support.",
    service: "Networking",
    features: ["Enterprise Grade", "Secure Setup", "24/7 Support"],
    gradient: "from-green-600 via-emerald-600 to-teal-600"
  },
  {
    image: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?q=80&w=4000&auto=format&fit=crop",
    title: "Strategic IT Consulting",
    subtitle: "Expert technology guidance with digital transformation strategies, optimization plans, and growth acceleration.",
    service: "IT Consulting",
    features: ["Digital Strategy", "Tech Optimization", "Growth Focus"],
    gradient: "from-amber-600 via-orange-600 to-red-600"
  }];


  const [currentSlide, setCurrentSlide] = React.useState(0);

  React.useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) =>
      prev === serviceSlides.length - 1 ? 0 : prev + 1
      );
    }, 6000);

    return () => clearInterval(interval);
  }, [serviceSlides.length]);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Dynamic Service Slideshow Background */}
      <div className="absolute inset-0 z-0">
        {serviceSlides.map((slide, index) =>
        <motion.div
          key={index}
          className="absolute inset-0"
          initial={{ opacity: 0 }}
          animate={{
            opacity: index === currentSlide ? 1 : 0,
            scale: index === currentSlide ? 1.05 : 1
          }}
          transition={{ duration: 2.5, ease: "easeInOut" }}>

            <img
            src={slide.image}
            alt={slide.service}
            className="w-full h-full object-cover" />

            <div className={`absolute inset-0 bg-gradient-to-r ${slide.gradient}/80`}></div>
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/40"></div>
          </motion.div>
        )}
      </div>

      {/* Enhanced Background Effects */}
      <div className="absolute inset-0 z-10">
        <motion.div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-white/10 via-cyan-300/20 to-blue-400/10 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.6, 0.3],
            rotate: [0, 360]
          }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "easeInOut"
          }} />

        
        {/* Floating particles */}
        {[...Array(10)].map((_, i) =>
        <motion.div
          key={i}
          className="absolute w-2 h-2 bg-white/40 rounded-full"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`
          }}
          animate={{
            y: [0, -50, 0],
            opacity: [0, 1, 0],
            scale: [1, 1.5, 1]
          }}
          transition={{
            duration: 4 + Math.random() * 2,
            repeat: Infinity,
            delay: Math.random() * 2,
            ease: "easeInOut"
          }} />

        )}
      </div>

      <motion.div
        className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
        variants={containerVariants}
        initial="hidden"
        animate="visible">

        <div className="max-w-6xl mx-auto">
          {/* Enhanced Dynamic Service Badge */}
          <motion.div
            variants={fadeInUp}
            className="mb-8"
            key={currentSlide}
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 1 }}>

            <div className="inline-flex items-center px-8 py-4 bg-white/15 backdrop-blur-xl rounded-full border border-white/20 shadow-2xl">
              <Star className="w-5 h-5 text-yellow-300 mr-3" />
              <span className="text-white font-bold text-xl tracking-wide">{serviceSlides[currentSlide].service}</span>
              <div className="ml-3 flex space-x-1">
                {[...Array(5)].map((_, i) =>
                <Star key={i} className="w-3 h-3 text-yellow-300 fill-current" />
                )}
              </div>
            </div>
          </motion.div>

          {/* Dynamic Main Headlines with Better Typography */}
          <div className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl xl:text-8xl font-black text-white mb-8 leading-tight">
            <motion.div
              key={`title-${currentSlide}`}
              variants={slideFromLeft}
              initial={{ opacity: 0, x: -100, scale: 0.9 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              transition={{ duration: 1.2, delay: 0.3, type: "spring", stiffness: 100 }}
              className="mb-4 drop-shadow-2xl">

              {serviceSlides[currentSlide].title.split(' ').slice(0, -1).join(' ')}
            </motion.div>
            <motion.div
              key={`subtitle-${currentSlide}`}
              variants={slideFromRight}
              initial={{ opacity: 0, x: 100, scale: 0.9 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              transition={{ duration: 1.2, delay: 0.5, type: "spring", stiffness: 100 }}
              className="bg-gradient-to-r from-cyan-200 via-white to-blue-200 bg-clip-text text-transparent drop-shadow-xl">

              {serviceSlides[currentSlide].title.split(' ').slice(-1)}
            </motion.div>
          </div>

          {/* Enhanced Service Description */}
          <motion.div
            key={`description-${currentSlide}`}
            variants={fadeInUp}
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 1.2, delay: 0.7 }}
            className="mb-8">

            <p className="text-xl md:text-2xl lg:text-3xl text-white/90 mb-8 max-w-5xl mx-auto leading-relaxed font-medium drop-shadow-lg">
              {serviceSlides[currentSlide].subtitle}
            </p>
            
            {/* Feature Tags */}
            <div className="flex flex-wrap justify-center gap-4 mb-12">
              {serviceSlides[currentSlide].features.map((feature, i) =>
              <motion.div
                key={feature}
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.9 + i * 0.1, duration: 0.5, type: "spring" }}
                className="px-6 py-3 bg-white/20 backdrop-blur-md rounded-full border border-white/30 shadow-xl">

                  <span className="text-white font-semibold text-lg flex items-center">
                    <Zap className="w-4 h-4 mr-2 text-yellow-300" />
                    {feature}
                  </span>
                </motion.div>
              )}
            </div>
          </motion.div>

          {/* Enhanced Slideshow Indicators */}
          <motion.div
            variants={fadeInUp}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1.2, delay: 1.1 }}
            className="flex justify-center space-x-4 mb-16">

            {serviceSlides.map((_, index) =>
            <motion.button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`transition-all duration-500 rounded-full ${
              index === currentSlide ?
              "w-16 h-4 bg-white shadow-lg" :
              "w-4 h-4 bg-white/40 hover:bg-white/60"}`
              }
              whileHover={{ scale: 1.2 }}
              whileTap={{ scale: 0.9 }} />

            )}
          </motion.div>
        </div>
      </motion.div>
    </section>);

}
