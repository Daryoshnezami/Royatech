import { base44 } from './base44Client';


export const Service = base44.entities.Service;

export const Project = base44.entities.Project;

export const BlogPost = base44.entities.BlogPost;

export const Contact = base44.entities.Contact;



// auth sdk:
export const User = base44.auth;