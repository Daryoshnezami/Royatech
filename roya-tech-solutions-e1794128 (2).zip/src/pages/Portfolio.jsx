
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion, AnimatePresence } from "framer-motion";
import { 
  ExternalLink, 
  ArrowRight,
  Code,
  Smartphone,
  Shield,
  Star,
  Sparkles,
  Eye,
  TrendingUp,
  Award
} from "lucide-react";

export default function Portfolio() {
  const [activeCategory, setActiveCategory] = useState("all");

  // Enhanced Portfolio with Better Results and Details
  const projects = [
    {
      title: "Alpha Platform",
      description: "Comprehensive enterprise business management platform featuring advanced analytics, real-time reporting, automated workflows, and integrated CRM capabilities for Fortune 500 companies.",
      client: "Alpha Corporation",
      category: "web_development",
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=2940&auto=format&fit=crop",
      technologies: ["React", "Node.js", "MongoDB", "AWS", "Redis", "Docker"],
      results: "300% performance improvement",
      metrics: {
        users: "50K+",
        uptime: "99.9%",
        performance: "3x faster"
      },
      featured: true,
      year: "2024"
    },
    {
      title: "Kamistor E-Commerce",
      description: "Modern multi-vendor e-commerce platform with advanced inventory management, AI-powered recommendations, integrated payment processing, and comprehensive analytics dashboard.",
      client: "Kamistor Ltd",
      category: "web_development",
      image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?q=80&w=2940&auto=format&fit=crop",
      technologies: ["Next.js", "Stripe", "PostgreSQL", "Redis", "Docker", "AI/ML"],
      results: "250% increase in online sales",
      metrics: {
        revenue: "+250%",
        conversion: "12.5%",
        users: "100K+"
      },
      featured: true,
      year: "2024"
    },
    {
      title: "Homebit Smart App",
      description: "Revolutionary IoT-enabled smart home application with device automation, energy monitoring, AI-powered optimization, and voice control integration for residential and commercial use.",
      client: "Homebit Technologies",
      category: "app_development",
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?q=80&w=2940&auto=format&fit=crop",
      technologies: ["React Native", "IoT", "Firebase", "Machine Learning", "AWS IoT"],
      results: "100,000+ downloads worldwide",
      metrics: {
        downloads: "100K+",
        rating: "4.8/5",
        devices: "500K+"
      },
      featured: true,
      year: "2023"
    },
    {
      title: "Koor Food Delivery",
      description: "Full-featured food delivery platform with real-time GPS tracking, integrated payment systems, advanced restaurant management tools, and AI-powered delivery optimization.",
      client: "Koor Foods",
      category: "app_development",
      image: "https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?q=80&w=2940&auto=format&fit=crop",
      technologies: ["Flutter", "Google Maps API", "Payment Gateway", "WebRTC", "Firebase"],
      results: "50,000+ active users daily",
      metrics: {
        users: "50K+ daily",
        orders: "1M+ monthly",
        rating: "4.7/5"
      },
      featured: false,
      year: "2023"
    },
    {
      title: "Bost Analytics Platform",
      description: "Advanced business intelligence platform with real-time data visualization, predictive analytics, machine learning insights, and comprehensive reporting for enterprise clients.",
      client: "Bost Analytics",
      category: "web_development",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2940&auto=format&fit=crop",
      technologies: ["Vue.js", "Python", "TensorFlow", "Apache Kafka", "Elasticsearch"],
      results: "Real-time insights for 1000+ businesses",
      metrics: {
        businesses: "1000+",
        data: "10TB+ daily",
        insights: "Real-time"
      },
      featured: false,
      year: "2023"
    },
    {
      title: "Half Price Marketplace",
      description: "Large-scale B2B/B2C marketplace platform with advanced search capabilities, secure payment processing, comprehensive vendor management, and automated logistics integration.",
      client: "Half Price Ltd",
      category: "web_development",
      image: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?q=80&w=2940&auto=format&fit=crop",
      technologies: ["React", "Microservices", "Docker", "Elasticsearch", "Kubernetes"],
      results: "1M+ transactions processed",
      metrics: {
        transactions: "1M+",
        vendors: "5000+",
        volume: "$50M+"
      },
      featured: false,
      year: "2022"
    },
    {
      title: "Afghan Spuries Security",
      description: "Comprehensive cybersecurity implementation with advanced threat detection, network security hardening, employee training programs, and 24/7 monitoring for enterprise security.",
      client: "Afghan Spuries Corp",
      category: "security",
      image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2940&auto=format&fit=crop",
      technologies: ["Nessus", "Splunk", "Firewall Config", "Penetration Testing", "SIEM"],
      results: "Zero security breaches since deployment",
      metrics: {
        threats: "99.99% blocked",
        uptime: "100%",
        compliance: "SOC 2"
      },
      featured: false,
      year: "2022"
    },
    {
      title: "TechFlow CRM Suite",
      description: "Complete customer relationship management suite with sales automation, marketing tools, customer analytics, and integrated communication platform for growing businesses.",
      client: "TechFlow Solutions",
      category: "web_development",
      image: "https://images.unsplash.com/photo-1553028826-f4804a6dba3b?q=80&w=2940&auto=format&fit=crop",
      technologies: ["Angular", "NestJS", "PostgreSQL", "Redis", "WebSocket"],
      results: "400% increase in sales productivity",
      metrics: {
        productivity: "+400%",
        leads: "10K+ monthly",
        automation: "85%"
      },
      featured: false,
      year: "2024"
    }
  ];

  const filteredProjects = activeCategory === "all" 
    ? projects 
    : projects.filter(project => project.category === activeCategory);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 30, scale: 0.95 },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        duration: 0.8,
        ease: "easeOut",
      },
    },
  };

  return (
    <div className="bg-gradient-to-br from-slate-50 via-blue-50/30 to-indigo-50/20 min-h-screen">
      
      {/* Enhanced Hero Section */}
      <section className="relative overflow-hidden py-24 lg:py-32">
        {/* Animated Background */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600"></div>
          <div className="absolute inset-0 opacity-30">
            {[...Array(15)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-3 h-3 bg-white rounded-full"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                }}
                animate={{
                  y: [0, -30, 0],
                  opacity: [0, 1, 0],
                  scale: [1, 1.5, 1],
                }}
                transition={{
                  duration: 3 + Math.random() * 2,
                  repeat: Infinity,
                  delay: Math.random() * 2,
                  ease: "easeInOut"
                }}
              />
            ))}
          </div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center z-10">
          <motion.div 
            initial="hidden"
            animate="visible"
            variants={containerVariants}
          >
            <motion.div variants={cardVariants}>
              <Badge className="mb-8 bg-white/20 text-white hover:bg-white/30 transition-all border border-white/30 text-lg px-6 py-3">
                <Award className="w-5 h-5 mr-2" />
                Our Portfolio
              </Badge>
            </motion.div>
            <motion.h1 
              className="text-5xl md:text-7xl font-bold text-white mb-8 leading-tight"
              variants={cardVariants}
            >
              Exceptional
              <span className="block bg-gradient-to-r from-cyan-300 via-white to-blue-300 bg-clip-text text-transparent">
                Project Results
              </span>
            </motion.h1>
            <motion.p 
              className="text-xl md:text-2xl text-blue-100 mb-12 max-w-4xl mx-auto leading-relaxed"
              variants={cardVariants}
            >
              Discover our portfolio of successful digital transformations. Each project represents 
              measurable business impact, cutting-edge technology, and exceptional client satisfaction.
            </motion.p>
            
            {/* Stats Banner */}
            <motion.div 
              className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto"
              variants={cardVariants}
            >
              {[
                { number: "500+", label: "Projects Delivered" },
                { number: "99.9%", label: "Client Satisfaction" },
                { number: "15+", label: "Years Experience" },
                { number: "200+", label: "Happy Clients" }
              ].map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="text-3xl md:text-4xl font-bold text-white mb-2">{stat.number}</div>
                  <div className="text-blue-200 text-sm md:text-base">{stat.label}</div>
                </div>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Enhanced Portfolio Filter */}
      <section className="py-16 bg-white/80 backdrop-blur-md border-b border-blue-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-center mb-8">
            <Tabs value={activeCategory} onValueChange={setActiveCategory}>
              <TabsList className="bg-white/90 backdrop-blur-md p-2 shadow-xl border border-blue-200 rounded-2xl">
                <TabsTrigger value="all" className="data-[state=active]:bg-blue-500 data-[state=active]:text-white text-slate-700 px-8 py-4 text-lg font-semibold rounded-xl transition-all duration-300">
                  All Projects
                </TabsTrigger>
                <TabsTrigger value="web_development" className="data-[state=active]:bg-blue-500 data-[state=active]:text-white text-slate-700 px-8 py-4 text-lg font-semibold rounded-xl transition-all duration-300">
                  Web Development
                </TabsTrigger>
                <TabsTrigger value="app_development" className="data-[state=active]:bg-blue-500 data-[state=active]:text-white text-slate-700 px-8 py-4 text-lg font-semibold rounded-xl transition-all duration-300">
                  App Development
                </TabsTrigger>
                <TabsTrigger value="security" className="data-[state=active]:bg-blue-500 data-[state=active]:text-white text-slate-700 px-8 py-4 text-lg font-semibold rounded-xl transition-all duration-300">
                  Security
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          {/* Enhanced Projects Grid */}
          <AnimatePresence mode="wait">
            <motion.div 
              key={activeCategory}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10"
              initial="hidden"
              animate="visible"
              exit="hidden"
              variants={containerVariants}
            >
              {filteredProjects.map((project, index) => (
                <motion.div key={index} variants={cardVariants}>
                  <Card className="attractive-card group attractive-lift border-0 shadow-xl overflow-hidden h-full bg-gradient-to-br from-white via-white to-blue-50/50 hover:shadow-2xl transition-all duration-500">
                    <div className="relative overflow-hidden">
                      <img 
                        src={project.image} 
                        alt={project.title}
                        className="w-full h-72 object-cover transition-all duration-700 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                      
                      {/* Floating Badges */}
                      <div className="absolute top-4 left-4 right-4 flex justify-between items-start">
                        <div className="flex flex-col gap-2">
                          {project.featured && (
                            <Badge className="bg-yellow-500 text-white border-0 shadow-lg">
                              <Star className="w-3 h-3 mr-1 fill-current" />
                              Featured
                            </Badge>
                          )}
                          <Badge className="bg-blue-600 text-white border-0 shadow-lg">
                            {project.year}
                          </Badge>
                        </div>
                      </div>

                      {/* Hover Overlay */}
                      <div className="absolute bottom-4 left-4 right-4 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-4 group-hover:translate-y-0">
                        <Button variant="secondary" size="sm" className="w-full bg-white/95 text-slate-900 hover:bg-white shadow-lg backdrop-blur-md">
                          <Eye className="mr-2 h-4 w-4" />
                          View Case Study
                          <ExternalLink className="ml-2 h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <CardContent className="p-8 flex flex-col flex-grow">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center">
                          {project.category === "web_development" && <Code className="h-6 w-6 text-blue-500 mr-3" />}
                          {project.category === "app_development" && <Smartphone className="h-6 w-6 text-purple-500 mr-3" />}
                          {/* {project.category === "networking" && <Network className="h-6 w-6 text-green-500 mr-3" />} Keeping Network as it was in the original imports, though not used in the CTA change */}
                          {project.category === "security" && <Shield className="h-6 w-6 text-red-500 mr-3" />}
                          <span className="text-sm text-slate-500 capitalize font-medium">{project.category.replace('_', ' ')}</span>
                        </div>
                        <TrendingUp className="h-5 w-5 text-green-500" />
                      </div>
                      
                      <h3 className="text-2xl font-bold text-slate-900 mb-4 group-hover:text-blue-600 transition-colors duration-300">{project.title}</h3>
                      <p className="text-slate-700 mb-6 leading-relaxed flex-grow">{project.description}</p>
                      
                      <div className="mb-6">
                        <p className="text-sm text-slate-500 mb-2">Client: <span className="font-semibold text-slate-700">{project.client}</span></p>
                        <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-xl border border-green-200 mb-4">
                          <p className="text-lg text-green-700 font-bold flex items-center">
                            <TrendingUp className="w-5 h-5 mr-2" />
                            {project.results}
                          </p>
                        </div>

                        {/* Metrics */}
                        <div className="grid grid-cols-3 gap-2 mb-4">
                          {Object.entries(project.metrics).map(([key, value], i) => (
                            <div key={i} className="bg-blue-50 p-3 rounded-lg text-center border border-blue-200">
                              <div className="text-blue-700 font-bold text-sm">{value}</div>
                              <div className="text-blue-600 text-xs capitalize">{key}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <div className="flex flex-wrap gap-2">
                        {project.technologies.map((tech, techIndex) => (
                          <Badge key={techIndex} variant="outline" className="border-blue-200 text-blue-700 bg-blue-50 hover:bg-blue-100 transition-colors duration-300">
                            {tech}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </AnimatePresence>
        </div>
      </section>

      {/* Enhanced CTA Section */}
      <section className="py-24 relative">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.5 }}
            variants={{
              hidden: {opacity:0, scale:0.95, y: 50},
              visible: {opacity:1, scale:1, y: 0, transition:{duration:1}}
            }}
          >
            <div className="attractive-card p-16 shadow-2xl border-0 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-600/5 via-indigo-600/5 to-purple-600/5"></div>
              <div className="relative z-10">
                <h2 className="text-4xl md:text-6xl font-bold text-slate-900 mb-8">
                  Ready to Create Your
                  <span className="block bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                    Success Story?
                  </span>
                </h2>
                <p className="text-xl text-slate-700 mb-12 max-w-3xl mx-auto leading-relaxed">
                  Let's transform your vision into a digital reality. Join our portfolio of successful 
                  projects and experience the difference that expert technology solutions can make.
                </p>
                <div className="flex flex-col lg:flex-row gap-6 justify-center">
                  <Link to={createPageUrl("Contact")}>
                    <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      <Button size="lg" className="gradient-primary text-white hover:shadow-2xl transition-all duration-300 px-12 py-6 text-xl rounded-2xl font-semibold">
                        Start Your Project
                        <ArrowRight className="ml-3 h-7 w-7" />
                      </Button>
                    </motion.div>
                  </Link>
                  <Link to={createPageUrl("Services")}>
                    <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      <Button variant="outline" size="lg" className="border-2 border-blue-300 text-blue-700 hover:bg-blue-50 hover:border-blue-400 transition-all duration-300 px-12 py-6 text-xl rounded-2xl font-semibold">
                        Explore Our Services
                        <Sparkles className="ml-3 h-7 w-7" />
                      </Button>
                    </motion.div>
                  </Link>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
