
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from "framer-motion";
import { 
  Search, 
  Calendar, 
  User, 
  ArrowRight,
  Clock,
  TrendingUp
} from "lucide-react";
import { BlogPost } from "@/api/entities";

export default function Blog() {
  const [posts, setPosts] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  useEffect(() => {
    loadPosts();
  }, []);

  const loadPosts = async () => {
    const fetchedPosts = await BlogPost.filter({ published: true }, "-created_date");
    setPosts(fetchedPosts);
  };

  const filteredPosts = posts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory === "all" || post.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const featuredPosts = [
    {
      title: "The Future of Cloud Computing in 2025",
      excerpt: "Exploring emerging trends and technologies that will shape the cloud computing landscape in the coming year.",
      author: "Ahmed Al-Rashid",
      category: "technology",
      image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=600&h=400&fit=crop",
      readTime: "8 min read",
      date: "2025-01-15"
    },
    {
      title: "Cybersecurity Best Practices for Small Businesses",
      excerpt: "Essential security measures that every small business should implement to protect against cyber threats.",
      author: "Sarah Mitchell",
      category: "technology",
      image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=600&h=400&fit=crop",
      readTime: "6 min read",
      date: "2025-01-10"
    },
    {
      title: "AI Integration in Modern Web Development",
      excerpt: "How artificial intelligence is revolutionizing the way we build and interact with web applications.",
      author: "David Chen",
      category: "technology",
      image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=600&h=400&fit=crop",
      readTime: "10 min read",
      date: "2025-01-05"
    }
  ];

  const categories = [
    { value: "all", label: "All Posts" },
    { value: "technology", label: "Technology" },
    { value: "industry_news", label: "Industry News" },
    { value: "company_updates", label: "Company Updates" },
    { value: "tutorials", label: "Tutorials" }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 50, scale: 0.95 },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        duration: 0.8,
        ease: "easeOut",
      },
    },
  };

  const floatingAnimation = {
    y: [-10, 10],
    transition: {
      duration: 3,
      repeat: Infinity,
      repeatType: "reverse",
      ease: "easeInOut",
    },
  };

  return (
    <div className="animate-fade-in relative">
      {/* Floating Background Elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <motion.div
          className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl"
          animate={floatingAnimation}
        />
        <motion.div
          className="absolute top-3/4 right-1/4 w-72 h-72 bg-purple-500/5 rounded-full blur-3xl"
          animate={{
            y: [10, -10],
            transition: {
              duration: 4,
              repeat: Infinity,
              repeatType: "reverse",
              ease: "easeInOut",
            },
          }}
        />
        <motion.div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-blue-500/5 rounded-full blur-3xl"
          animate={{
            y: [-15, 15],
            transition: {
              duration: 5,
              repeat: Infinity,
              repeatType: "reverse",
              ease: "easeInOut",
            },
          }}
        />
      </div>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-32">
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center"
            initial="hidden"
            animate="visible"
            variants={containerVariants}
          >
            <motion.div variants={cardVariants}>
              <Badge className="mb-6 bg-cyan-500/10 text-cyan-300 hover:bg-cyan-500/20 transition-colors border border-cyan-500/20">
                Tech Insights Blog
              </Badge>
            </motion.div>
            <motion.h1 
              className="text-4xl md:text-6xl font-bold text-white mb-8 leading-tight"
              variants={cardVariants}
            >
              Latest
              <span className="block gradient-text">Tech Insights</span>
            </motion.h1>
            <motion.p 
              className="text-lg md:text-xl text-slate-300 mb-10 max-w-3xl mx-auto leading-relaxed"
              variants={cardVariants}
            >
              Stay updated with the latest trends, insights, and innovations in technology. 
              Our experts share their knowledge and experience to help you make informed decisions.
            </motion.p>
          </motion.div>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="py-12 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-6 items-center justify-between">
            <div className="relative flex-1 max-w-md input-glow-group">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input
                placeholder="Search articles..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-slate-800 border-slate-700 text-white placeholder:text-slate-400"
              />
            </div>
            <Tabs value={activeCategory} onValueChange={setActiveCategory}>
              <TabsList className="bg-slate-800 p-1">
                {categories.map(category => (
                  <TabsTrigger key={category.value} value={category.value} className="data-[state=active]:bg-slate-700 data-[state=active]:text-white text-slate-300">
                    {category.label}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          </div>
        </div>
      </section>

      {/* Featured Posts */}
      <section className="py-20 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900/50 via-blue-900/30 to-slate-900/50"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={containerVariants}
          >
            <motion.div className="text-center mb-16" variants={cardVariants}>
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Featured Articles
              </h2>
              <p className="text-lg text-slate-300 max-w-3xl mx-auto">
                Our most popular and impactful articles on technology trends and innovations
              </p>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {featuredPosts.map((post, index) => (
                <motion.div key={index} variants={cardVariants}>
                  <Card className="group hover-lift bg-slate-800/30 border border-white/10 backdrop-blur-xl hover:shadow-[0_0_35px_rgba(6,182,212,0.3)] hover:border-cyan-400/60 transition-all duration-500 overflow-hidden">
                    <div className="relative">
                      <img 
                        src={post.image} 
                        alt={post.title}
                        className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                      <div className="absolute top-4 left-4">
                        <Badge className="bg-cyan-500/10 text-cyan-300 border-cyan-500/20">
                          Featured
                        </Badge>
                      </div>
                    </div>
                    
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4 mb-4 text-sm text-slate-400">
                        <div className="flex items-center gap-1">
                          <User className="h-4 w-4" />
                          <span>{post.author}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          <span>{new Date(post.date).toLocaleDateString()}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          <span>{post.readTime}</span>
                        </div>
                      </div>
                      
                      <h3 className="text-xl font-semibold text-white mb-3 group-hover:text-cyan-400 transition-colors">
                        {post.title}
                      </h3>
                      <p className="text-slate-50 mb-4 leading-relaxed">{post.excerpt}</p>
                      
                      <Button variant="ghost" className="p-0 h-auto text-cyan-400 hover:text-cyan-300">
                        Read More
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Recent Posts */}
      <section className="py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={containerVariants}
          >
            <motion.div className="text-center mb-16" variants={cardVariants}>
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Recent Articles
              </h2>
              <p className="text-lg text-slate-300 max-w-3xl mx-auto">
                {filteredPosts.length > 0 ? `${filteredPosts.length} articles found` : "No articles found matching your criteria"}
              </p>
            </motion.div>

            {filteredPosts.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-24 h-24 mx-auto mb-6 bg-slate-800 rounded-full flex items-center justify-center">
                  <Search className="h-12 w-12 text-gray-400" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-4">No articles found</h3>
                <p className="text-slate-300 mb-8">Try adjusting your search or browse our featured articles above.</p>
                <Button onClick={() => { setSearchTerm(""); setActiveCategory("all"); }} variant="outline" className="border-cyan-500/50 text-cyan-300 hover:bg-cyan-500/20 hover:border-cyan-400 transition-all duration-300 backdrop-blur-md">
                  Clear Filters
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredPosts.map((post, index) => (
                  <motion.div key={index} variants={cardVariants}>
                    <Card className="group hover-lift bg-slate-800/30 border border-white/10 backdrop-blur-xl hover:shadow-[0_0_35px_rgba(6,182,212,0.3)] hover:border-cyan-400/60 transition-all duration-500">
                      <CardContent className="p-6">
                        <div className="flex items-center gap-4 mb-4 text-sm text-slate-400">
                          <div className="flex items-center gap-1">
                            <User className="h-4 w-4" />
                            <span>{post.author}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            <span>{new Date(post.created_date).toLocaleDateString()}</span>
                          </div>
                        </div>
                        
                        <Badge className="mb-3 bg-cyan-500/10 text-cyan-300 border-cyan-500/20">
                          {post.category.replace('_', ' ')}
                        </Badge>
                        
                        <h3 className="text-xl font-semibold text-white mb-3 group-hover:text-cyan-400 transition-colors">
                          {post.title}
                        </h3>
                        <p className="text-slate-50 mb-4 leading-relaxed">{post.excerpt}</p>
                        
                        <Button variant="ghost" className="p-0 h-auto text-cyan-400 hover:text-cyan-300">
                          Read More
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            )}
          </motion.div>
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-20 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-slate-900/30 to-transparent"></div>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.5 }}
            variants={{
              hidden: {opacity:0, scale:0.9},
              visible: {opacity:1, scale:1, transition:{duration:0.8}}
            }}
          >
            <div className="bg-slate-800/30 border border-cyan-500/20 backdrop-blur-xl rounded-2xl p-12 text-white shadow-[0_0_35px_rgba(6,182,212,0.3)]">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Stay Updated
              </h2>
              <p className="text-lg mb-8 max-w-2xl mx-auto text-slate-300">
                Subscribe to our newsletter and get the latest tech insights, 
                industry trends, and company updates delivered to your inbox.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
                <div className="input-glow-group flex-1">
                  <Input 
                    placeholder="Enter your email address"
                    className="bg-slate-900/50 border-slate-700 text-white placeholder:text-slate-400"
                  />
                </div>
                <Button className="gradient-accent-bg text-white hover:shadow-2xl hover:shadow-cyan-500/30 transition-all duration-300 pulse-glow-button">
                  Subscribe
                  <TrendingUp className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
