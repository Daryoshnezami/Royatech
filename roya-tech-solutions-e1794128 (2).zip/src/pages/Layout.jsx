

import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Menu, X, Phone, Mail, MapPin, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import Logo from "./components/common/Logo";
import { motion, AnimatePresence } from "framer-motion";

const navigationItems = [
  { title: "Home", url: createPageUrl("Home") },
  { title: "About", url: createPageUrl("About") },
  { title: "Services", url: createPageUrl("Services") },
  { title: "Portfolio", url: createPageUrl("Portfolio") },
  { title: "Contact", url: createPageUrl("Contact") }
];


export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  const whatsappUrl = "https://wa.me/19164651850?text=Hello%20ROYA%20Tech,%20I'm%20interested%20in%20your%20services.";

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-indigo-50/20 text-slate-800">
      <style>
        {`
          @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-12px) rotate(1deg); }
          }
          @keyframes pulse-glow {
            0%, 100% { box-shadow: 0 0 20px rgba(14, 165, 233, 0.4); }
            50% { box-shadow: 0 0 30px rgba(14, 165, 233, 0.7); }
          }
          body {
            background: linear-gradient(135deg, #f8fafc 0%, #e0f2fe 50%, #f0f9ff 100%);
            color: #1e293b;
          }
          :root {
            --primary-accent: #0ea5e9;
            --secondary-accent: #3b82f6;
            --gradient-primary: linear-gradient(135deg, #0ea5e9 0%, #3b82f6 50%, #6366f1 100%);
            --gradient-secondary: linear-gradient(135deg, #06b6d4 0%, #0ea5e9 100%);
            --shadow-soft: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
          }
          .attractive-header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(59, 130, 246, 0.1);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
          }
          .gradient-primary {
            background: var(--gradient-primary);
          }
          .gradient-secondary {
            background: var(--gradient-secondary);
          }
          .gradient-text {
            background: var(--gradient-primary);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
          }
          .attractive-lift {
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
          }
          .attractive-lift:hover {
            transform: translateY(-12px) scale(1.02);
            box-shadow: 0 25px 50px -12px rgba(59, 130, 246, 0.25);
          }
          .magnetic-hover {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          }
          .magnetic-hover:hover {
            transform: translateY(-4px) scale(1.05);
            box-shadow: 0 15px 35px rgba(14, 165, 233, 0.3);
          }
          .floating-element {
            animation: float 6s ease-in-out infinite;
          }
          .pulse-glow-animation {
            animation: pulse-glow 2s ease-in-out infinite;
          }
          .attractive-card {
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(59, 130, 246, 0.1);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
          }
          .attractive-card:hover {
            background: rgba(255, 255, 255, 0.95);
            border: 1px solid rgba(59, 130, 246, 0.3);
            transform: translateY(-8px);
            box-shadow: 0 20px 40px rgba(59, 130, 246, 0.15);
          }
          
          /* Enhanced Responsive Design */
          @media (max-width: 320px) {
            .text-4xl { font-size: 1.75rem; line-height: 1.2; }
            .text-6xl { font-size: 2.25rem; line-height: 1.1; }
            .px-4 { padding-left: 1rem; padding-right: 1rem; }
            .py-20 { padding-top: 3rem; padding-bottom: 3rem; }
          }
          @media (min-width: 1200px) {
            .container-xl { max-width: 1280px; }
          }
        `}
      </style>

      {/* Enhanced Header */}
      <motion.header
        className="attractive-header fixed top-0 left-0 right-0 z-50"
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-18 md:h-20">
            {/* Logo */}
            <Link to={createPageUrl("Home")}>
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                transition={{ type: "spring", stiffness: 300 }}>

                <Logo />
              </motion.div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-2">
              {navigationItems.map((item, index) =>
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1, duration: 0.5 }}>

                  <Link
                  to={item.url}
                  className={`relative px-5 py-3 text-sm font-semibold transition-all duration-300 rounded-xl group ${
                  location.pathname === item.url ?
                  "text-blue-600 bg-blue-50" :
                  "text-slate-700 hover:text-blue-600 hover:bg-blue-50/50"}`
                  }>

                    <span className="relative z-10">{item.title}</span>
                    {location.pathname === item.url &&
                  <motion.div
                    className="absolute bottom-1 left-1/2 -translate-x-1/2 h-1 w-6 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full"
                    layoutId="activeNav"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }} />

                  }
                  </Link>
                </motion.div>
              )}
            </nav>

            {/* CTA Button */}
            <motion.div
              className="hidden md:block"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6, duration: 0.5 }}>

              <Link to={createPageUrl("Contact")}>
                <Button className="gradient-primary text-white hover:shadow-lg transition-all duration-300 hover:scale-105 magnetic-hover px-6 py-3 rounded-xl font-semibold">
                  Get Started
                </Button>
              </Link>
            </motion.div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <motion.div whileTap={{ scale: 0.9 }}>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                  className="text-slate-800 hover:bg-blue-50 magnetic-hover">

                  <AnimatePresence mode="wait">
                    {isMobileMenuOpen ?
                    <motion.div
                      key="close"
                      initial={{ rotate: -90, opacity: 0 }}
                      animate={{ rotate: 0, opacity: 1 }}
                      exit={{ rotate: 90, opacity: 0 }}
                      transition={{ duration: 0.2 }}>

                        <X className="h-6 w-6" />
                      </motion.div> :

                    <motion.div
                      key="menu"
                      initial={{ rotate: 90, opacity: 0 }}
                      animate={{ rotate: 0, opacity: 1 }}
                      exit={{ rotate: -90, opacity: 0 }}
                      transition={{ duration: 0.2 }}>

                        <Menu className="h-6 w-6" />
                      </motion.div>
                    }
                  </AnimatePresence>
                </Button>
              </motion.div>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        <AnimatePresence>
          {isMobileMenuOpen &&
          <motion.div
            className="md:hidden attractive-header border-t border-blue-100"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}>

              <div className="px-2 pt-2 pb-3 space-y-1">
                {navigationItems.map((item, index) =>
              <motion.div
                key={item.title}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1, duration: 0.3 }}>

                    <Link
                  to={item.url}
                  className={`block px-4 py-3 text-base font-medium rounded-xl transition-all duration-300 ${
                  location.pathname === item.url ?
                  "text-blue-600 bg-blue-50" :
                  "text-slate-700 hover:text-blue-600 hover:bg-blue-50"}`
                  }
                  onClick={() => setIsMobileMenuOpen(false)}>

                      {item.title}
                    </Link>
                  </motion.div>
              )}
                <motion.div
                className="pt-2 px-2"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, duration: 0.3 }}>

                  <Link to={createPageUrl("Contact")}>
                    <Button
                    className="w-full gradient-primary text-white rounded-xl font-semibold py-3"
                    onClick={() => setIsMobileMenuOpen(false)}>

                      Get Started
                    </Button>
                  </Link>
                </motion.div>
              </div>
            </motion.div>
          }
        </AnimatePresence>
      </motion.header>

      {/* Main Content */}
      <main className="pt-18 md:pt-20 relative z-10">
        {children}
      </main>

      {/* Enhanced Footer */}
      <motion.footer
        className="bg-gradient-to-br from-slate-800 via-slate-900 to-blue-900 text-white relative z-10 overflow-hidden"
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}>

        {/* Beautiful Animated Circles Background */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {/* Small glowing moving circles */}
          {[...Array(20)].map((_, i) =>
          <motion.div
            key={i}
            className="absolute rounded-full bg-gradient-to-r from-blue-400/30 via-cyan-400/40 to-purple-400/30 blur-sm"
            style={{
              width: Math.random() * 40 + 20,
              height: Math.random() * 40 + 20,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`
            }}
            animate={{
              x: [0, Math.random() * 100 - 50, 0],
              y: [0, Math.random() * 100 - 50, 0],
              scale: [1, Math.random() * 0.5 + 0.8, 1],
              opacity: [0.3, 0.8, 0.3]
            }}
            transition={{
              duration: Math.random() * 10 + 8,
              repeat: Infinity,
              ease: "easeInOut",
              delay: Math.random() * 5
            }} />

          )}
          
          {/* Medium glowing circles */}
          {[...Array(8)].map((_, i) =>
          <motion.div
            key={`medium-${i}`}
            className="absolute rounded-full bg-gradient-to-r from-indigo-400/20 via-blue-400/30 to-cyan-400/20 blur-md"
            style={{
              width: Math.random() * 80 + 60,
              height: Math.random() * 80 + 60,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`
            }}
            animate={{
              x: [0, Math.random() * 150 - 75, 0],
              y: [0, Math.random() * 150 - 75, 0],
              scale: [0.8, 1.2, 0.8],
              opacity: [0.2, 0.6, 0.2],
              rotate: [0, 360]
            }}
            transition={{
              duration: Math.random() * 15 + 12,
              repeat: Infinity,
              ease: "easeInOut",
              delay: Math.random() * 3
            }} />

          )}
          
          {/* Large background circles */}
          {[...Array(3)].map((_, i) =>
          <motion.div
            key={`large-${i}`}
            className="absolute rounded-full bg-gradient-to-r from-purple-500/10 via-blue-500/15 to-cyan-500/10 blur-3xl"
            style={{
              width: Math.random() * 200 + 150,
              height: Math.random() * 200 + 150,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`
            }}
            animate={{
              x: [0, Math.random() * 200 - 100, 0],
              y: [0, Math.random() * 200 - 100, 0],
              scale: [1, Math.random() * 0.4 + 1.2, 1],
              opacity: [0.1, 0.4, 0.1]
            }}
            transition={{
              duration: Math.random() * 20 + 15,
              repeat: Infinity,
              ease: "easeInOut",
              delay: Math.random() * 2
            }} />

          )}
        </div>

        {/* Footer Background Animation - Enhanced */}
        <div className="absolute inset-0 opacity-20">
          <motion.div
            className="absolute top-10 left-10 w-32 h-32 bg-blue-400 rounded-full blur-3xl"
            animate={{
              scale: [1, 1.5, 1],
              opacity: [0.3, 0.7, 0.3],
              x: [0, 50, 0],
              y: [0, -30, 0]
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: "easeInOut"
            }} />

          <motion.div
            className="absolute bottom-10 right-10 w-40 h-40 bg-indigo-400 rounded-full blur-3xl"
            animate={{
              scale: [1, 1.3, 1],
              opacity: [0.3, 0.6, 0.3],
              x: [0, -60, 0],
              y: [0, 40, 0]
            }}
            transition={{
              duration: 10,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 2
            }} />

          <motion.div
            className="absolute top-1/2 left-1/3 w-24 h-24 bg-cyan-400 rounded-full blur-2xl"
            animate={{
              scale: [0.8, 1.4, 0.8],
              opacity: [0.2, 0.8, 0.2],
              rotate: [0, 180, 360]
            }}
            transition={{
              duration: 12,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 4
            }} />

        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            {/* Company Info */}
            <motion.div
              className="col-span-1 md:col-span-2 lg:col-span-1"
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1, duration: 0.6 }}>

              <div className="mb-8">
                <h3 className="text-3xl font-bold tracking-wider gradient-text mb-2">ROYA TECH</h3>
                <p className="text-blue-300 text-sm tracking-widest">INFORMATION TECHNOLOGY</p>
              </div>
              <p className="text-slate-300 mb-8 max-w-md leading-relaxed text-lg">
                Leading technology solutions provider specializing in digital transformation and innovative business solutions.
              </p>
            </motion.div>

            {/* Contact Info */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2, duration: 0.6 }}>

              <h3 className="text-xl font-bold mb-6 text-blue-300">Contact Info</h3>
              <div className="space-y-4">
                <motion.div
                  className="flex items-center space-x-4 group cursor-pointer"
                  whileHover={{ x: 5 }}
                  transition={{ type: "spring", stiffness: 300 }}>

                  <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Phone className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-slate-300 group-hover:text-blue-300 transition-colors">+1 (916) 465-1850</span>
                </motion.div>
                <motion.div
                  className="flex items-center space-x-4 group cursor-pointer"
                  whileHover={{ x: 5 }}
                  transition={{ type: "spring", stiffness: 300 }}>

                  <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Mail className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-slate-300 group-hover:text-blue-300 transition-colors">info@royatech.com</span>
                </motion.div>
                <motion.div
                  className="flex items-center space-x-4 group cursor-pointer"
                  whileHover={{ x: 5 }}
                  transition={{ type: "spring", stiffness: 300 }}>

                  <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                    <MapPin className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-slate-300 group-hover:text-blue-300 transition-colors">1201 Fulton Ave, Sacramento, CA 95825</span>
                </motion.div>
              </div>
            </motion.div>

            {/* Services */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3, duration: 0.6 }}>

              <h3 className="text-xl font-bold mb-6 text-blue-300">Services</h3>
              <ul className="space-y-3">
                {["Web Development", "App Development", "Cloud Solutions", "Cybersecurity", "IT Consulting"].map((service, index) =>
                <motion.li
                  key={service}
                  whileHover={{ x: 5 }}
                  transition={{ type: "spring", stiffness: 300 }}>

                    <Link to={createPageUrl("Services")} className="text-slate-300 hover:text-blue-300 transition-colors flex items-center group">
                      <div className="w-2 h-2 bg-blue-400 rounded-full mr-3 group-hover:scale-125 transition-transform"></div>
                      {service}
                    </Link>
                  </motion.li>
                )}
              </ul>
            </motion.div>

            {/* Quick Links */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4, duration: 0.6 }}>

              <h3 className="text-xl font-bold mb-6 text-blue-300">Quick Links</h3>
              <ul className="space-y-3">
                {[
                { name: "About Us", url: "About" },
                { name: "Portfolio", url: "Portfolio" },
                { name: "Contact", url: "Contact" }].
                map((link, index) =>
                <motion.li
                  key={link.name}
                  whileHover={{ x: 5 }}
                  transition={{ type: "spring", stiffness: 300 }}>

                    <Link to={createPageUrl(link.url)} className="text-slate-300 hover:text-blue-300 transition-colors flex items-center group">
                      <div className="w-2 h-2 bg-blue-400 rounded-full mr-3 group-hover:scale-125 transition-transform"></div>
                      {link.name}
                    </Link>
                  </motion.li>
                )}
              </ul>
            </motion.div>
          </div>
        </div>

        {/* Footer Bottom */}
        <motion.div
          className="border-t border-slate-600 mt-12 pt-8 text-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5, duration: 0.6 }}>

          <p className="text-slate-400 text-lg">&copy; {new Date().getFullYear()} ROYA Tech. All rights reserved.</p>
          <p className="text-slate-500 mt-2">Privacy Policy | Terms of Service</p>
        </motion.div>
      </motion.footer>

      {/* Enhanced WhatsApp Chat Button */}
      <motion.a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 md:bottom-8 md:right-8 z-40"
        initial={{ opacity: 0, scale: 0.5, rotate: -180 }}
        animate={{ opacity: 1, scale: 1, rotate: 0 }}
        transition={{
          delay: 1.5,
          duration: 0.8,
          type: "spring",
          stiffness: 120
        }}
        whileHover={{
          scale: 1.15,
          rotate: [0, -5, 5, 0],
          transition: { duration: 0.3 }
        }}
        whileTap={{ scale: 0.9 }}
        aria-label="Chat on WhatsApp">

        <Button size="lg" className="gradient-primary text-white rounded-full shadow-2xl flex items-center justify-center h-16 w-16 md:h-18 md:w-18 floating-element pulse-glow-animation">
          <motion.div
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}>

            <MessageCircle className="h-8 w-8 md:h-9 md:w-9" />
          </motion.div>
        </Button>
      </motion.a>
    </div>);

}

