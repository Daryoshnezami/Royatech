
import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { 
  Target, 
  Eye, 
  Heart, 
  Users, 
  Award, 
  Lightbulb,
  ArrowRight,
  CheckCircle,
  Sparkles,
  Rocket,
  Star,
  TrendingUp,
  Globe,
  Shield,
  Zap
} from "lucide-react";

export default function About() {
  const values = [
    {
      icon: Lightbulb,
      title: "Innovation",
      description: "We stay ahead of technology trends to deliver cutting-edge solutions that drive business transformation and create competitive advantages.",
      color: "from-cyan-500 to-blue-600",
      stat: "50+ Technologies"
    },
    {
      icon: Heart,
      title: "Excellence",
      description: "We are committed to delivering the highest quality in everything we do, exceeding client expectations consistently with superior results.",
      color: "from-purple-500 to-pink-600",
      stat: "99.9% Quality"
    },
    {
      icon: Users,
      title: "Collaboration",
      description: "We work closely with our clients to understand their unique needs and build lasting partnerships that drive mutual success.",
      color: "from-blue-500 to-indigo-600",
      stat: "200+ Partnerships"
    },
    {
      icon: Shield,
      title: "Reliability",
      description: "We build trust through consistent, dependable service and proven track record of successful deliveries across all industries.",
      color: "from-green-500 to-emerald-600",
      stat: "15+ Years"
    }
  ];

  const teamMembers = [
    {
      name: "Saleem Nezami",
      role: "CEO & Founder",
      description: "",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
      expertise: [],
      experience: ""
    },
    {
      name: "Qais Nezami",
      role: "Lead Developer",
      description: "",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face",
      expertise: [],
      experience: ""
    },
    {
      name: "Mudasar Nezami",
      role: "App Developer",
      description: "",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face",
      expertise: [],
      experience: ""
    }
  ];

  const achievements = [
    {
      icon: Award,
      title: "ISO 27001 Certified",
      description: "Information Security Management certification ensuring highest security standards",
      year: "2023"
    },
    {
      icon: Star,
      title: "Microsoft Gold Partner",
      description: "Recognized expertise in Microsoft technologies and cloud solutions",
      year: "2022"
    },
    {
      icon: Shield,
      title: "AWS Advanced Partner",
      description: "Advanced consulting partner status with proven cloud expertise",
      year: "2023"
    },
    {
      icon: Globe,
      title: "Google Cloud Premier",
      description: "Premier partner recognition for exceptional Google Cloud implementations",
      year: "2023"
    },
    {
      icon: TrendingUp,
      title: "Top 100 IT Companies",
      description: "Named among the top 100 IT companies for innovation and growth",
      year: "2024"
    },
    {
      icon: Zap,
      title: "Excellence Award",
      description: "Industry recognition for outstanding service delivery and client satisfaction",
      year: "2024"
    }
  ];

  const stats = [
    { number: "15+", label: "Years Experience", icon: Award },
    { number: "500+", label: "Projects Completed", icon: Rocket },
    { number: "200+", label: "Happy Clients", icon: Users },
    { number: "50+", label: "Team Members", icon: Star }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 40, scale: 0.95 },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        duration: 0.8,
        ease: "easeOut",
      },
    },
  };

  return (
    <div className="bg-gradient-to-br from-slate-50 via-blue-50/30 to-indigo-50/20">
      
      {/* Enhanced Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-32 bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600">
        {/* Animated Background Pattern */}
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,${encodeURIComponent('<svg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="evenodd"><g fill="#ffffff" fill-opacity="0.1"><circle cx="30" cy="30" r="2"/></g></g></svg>')}")`,
          opacity: 0.3
        }}></div>
        
        {/* Floating Elements */}
        <div className="absolute inset-0 overflow-hidden">
          {[...Array(12)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-3 h-3 bg-white/20 rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                y: [0, -40, 0],
                opacity: [0, 1, 0],
                scale: [1, 1.5, 1],
              }}
              transition={{
                duration: 4 + Math.random() * 2,
                repeat: Infinity,
                delay: Math.random() * 2,
                ease: "easeInOut"
              }}
            />
          ))}
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 z-10">
          <motion.div 
            className="text-center"
            initial="hidden"
            animate="visible"
            variants={containerVariants}
          >
            <motion.div variants={cardVariants}>
              <div className="inline-flex items-center px-8 py-4 bg-white/20 backdrop-blur-md text-white rounded-full font-semibold text-lg mb-8">
                <Users className="w-5 h-5 mr-2" />
                About ROYA Tech
              </div>
            </motion.div>
            <motion.h1 
              className="text-5xl md:text-7xl font-bold text-white mb-10 leading-tight"
              variants={cardVariants}
            >
              Transforming Ideas Into
              <span className="block bg-gradient-to-r from-cyan-200 via-white to-blue-200 bg-clip-text text-transparent">
                Digital Reality
              </span>
            </motion.h1>
            <motion.p 
              className="text-xl md:text-2xl text-blue-100 mb-12 max-w-4xl mx-auto leading-relaxed"
              variants={cardVariants}
            >
              We are passionate innovators, dedicated to transforming businesses through cutting-edge 
              technology solutions that drive growth, enhance security, and deliver exceptional results.
            </motion.p>
            
            {/* Stats Row */}
            <motion.div 
              className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto"
              variants={cardVariants}
            >
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <stat.icon className="h-8 w-8 text-white" />
                  </div>
                  <div className="text-3xl md:text-4xl font-bold text-white mb-2">{stat.number}</div>
                  <div className="text-blue-200 font-medium">{stat.label}</div>
                </div>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Enhanced Mission & Vision */}
      <section className="py-24 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div 
            className="grid grid-cols-1 lg:grid-cols-2 gap-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={containerVariants}
          >
            <motion.div variants={cardVariants}>
              <Card className="attractive-card h-full attractive-lift border-0 shadow-xl overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-blue-600/5"></div>
                <CardContent className="p-12 relative z-10">
                  <div className="flex items-center mb-8">
                    <div className="w-20 h-20 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-2xl flex items-center justify-center mr-6 shadow-xl">
                      <Target className="h-10 w-10 text-white" />
                    </div>
                    <h2 className="text-3xl font-bold text-slate-900">Our Mission</h2>
                  </div>
                  <p className="text-slate-700 text-xl leading-relaxed mb-6">
                    To empower businesses with innovative technology solutions that drive growth, 
                    enhance security, and create competitive advantages in the digital marketplace.
                  </p>
                  <div className="flex items-center text-blue-600 font-semibold">
                    <Rocket className="w-5 h-5 mr-2" />
                    Driving Digital Excellence Since 2009
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={cardVariants}>
              <Card className="attractive-card h-full attractive-lift border-0 shadow-xl overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-pink-600/5"></div>
                <CardContent className="p-12 relative z-10">
                  <div className="flex items-center mb-8">
                    <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center mr-6 shadow-xl">
                      <Eye className="h-10 w-10 text-white" />
                    </div>
                    <h2 className="text-3xl font-bold text-slate-900">Our Vision</h2>
                  </div>
                  <p className="text-slate-700 text-xl leading-relaxed mb-6">
                    To be the leading technology partner that transforms how businesses operate 
                    in the digital age, creating unprecedented opportunities for innovation and growth.
                  </p>
                  <div className="flex items-center text-purple-600 font-semibold">
                    <Globe className="w-5 h-5 mr-2" />
                    Shaping the Future of Technology
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Enhanced Core Values */}
      <section className="py-24 relative bg-gradient-to-r from-slate-100 via-blue-50 to-indigo-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={containerVariants}
          >
            <motion.div className="text-center mb-20" variants={cardVariants}>
              <div className="inline-flex items-center px-6 py-3 bg-blue-100 text-blue-700 rounded-full font-semibold text-lg mb-8">
                <Heart className="w-5 h-5 mr-2" />
                Our Core Values
              </div>
              <p className="text-xl text-slate-700 max-w-4xl mx-auto leading-relaxed">
                Our values define our culture, drive our decisions, and shape our relationships with clients and partners.
              </p>
            </motion.div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
              {values.map((value, index) => (
                <motion.div key={index} variants={cardVariants}>
                  <Card className="attractive-card text-center h-full attractive-lift border-0 shadow-lg overflow-hidden group">
                    <div className="absolute inset-0 bg-gradient-to-br from-white via-white to-blue-50/50 group-hover:to-blue-100/50 transition-all duration-300"></div>
                    <CardContent className="p-10 relative z-10">
                      <motion.div 
                        className={`inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br ${value.color} mb-8 shadow-xl`}
                        whileHover={{ scale: 1.1, rotate: 5 }}
                        transition={{ duration: 0.3 }}
                      >
                        <value.icon className="h-10 w-10 text-white" />
                      </motion.div>
                      <div className="text-3xl font-bold text-blue-600 mb-2">{value.stat}</div>
                      <h3 className="text-2xl font-bold text-slate-900 mb-6">{value.title}</h3>
                      <p className="text-slate-700 leading-relaxed text-lg">{value.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Enhanced Team Section */}
      <section className="py-24 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={containerVariants}
          >
            <motion.div className="text-center mb-20" variants={cardVariants}>
              <div className="inline-flex items-center px-6 py-3 bg-indigo-100 text-indigo-700 rounded-full font-semibold text-lg mb-8">
                <Users className="w-5 h-5 mr-2" />
                Meet Our Experts
              </div>
              <h2 className="text-4xl md:text-6xl font-bold text-slate-900 mb-6">
                Our Expert Team
              </h2>
              <p className="text-xl text-slate-700 max-w-4xl mx-auto leading-relaxed">
                Our diverse team of technology experts brings years of experience, passion for innovation, 
                and dedication to delivering exceptional results.
              </p>
            </motion.div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10"> {/* Adjusted to 3 columns */}
              {teamMembers.map((member, index) => (
                <motion.div key={index} variants={cardVariants}>
                  <Card className="attractive-card text-center attractive-lift border-0 shadow-lg overflow-hidden group">
                    <div className="absolute inset-0 bg-gradient-to-br from-white via-white to-slate-50/50 group-hover:to-slate-100/50 transition-all duration-300"></div>
                    <CardContent className="p-8 relative z-10">
                      <div className="mb-8">
                        <div className="relative inline-block">
                          <img 
                            src={member.image} 
                            alt={member.name}
                            className="w-32 h-32 rounded-full mx-auto object-cover shadow-xl border-4 border-blue-200 group-hover:border-blue-300 transition-all duration-300"
                          />
                          <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center shadow-lg">
                            <Star className="h-5 w-5 text-white fill-current" />
                          </div>
                        </div>
                      </div>
                      <h3 className="text-2xl font-bold text-slate-900 mb-2">{member.name}</h3>
                      <p className="text-blue-600 font-semibold mb-2 text-lg">{member.role}</p>
                      {member.experience && <div className="text-sm text-slate-500 mb-4 font-medium">{member.experience}</div>}
                      {member.description && <p className="text-slate-700 leading-relaxed mb-6">{member.description}</p>}
                      
                      {/* Expertise Tags */}
                      {member.expertise.length > 0 && (
                        <div className="flex flex-wrap gap-2 justify-center">
                          {member.expertise.map((skill, i) => (
                            <Badge key={i} variant="outline" className="text-xs border-blue-200 text-blue-700 bg-blue-50">
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Enhanced Achievements */}
      <section className="py-24 relative bg-gradient-to-r from-slate-100 via-blue-50 to-indigo-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={containerVariants}
          >
            <motion.div className="text-center mb-20" variants={cardVariants}>
              <div className="inline-flex items-center px-6 py-3 bg-emerald-100 text-emerald-700 rounded-full font-semibold text-lg mb-8">
                <Award className="w-5 h-5 mr-2" />
                Our Achievements
              </div>
              <h2 className="text-4xl md:text-6xl font-bold text-slate-900 mb-6">
                Recognition & Certifications
              </h2>
              <p className="text-xl text-slate-700 max-w-4xl mx-auto leading-relaxed">
                Industry recognition and certifications that demonstrate our commitment to excellence and expertise.
              </p>
            </motion.div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {achievements.map((achievement, index) => (
                <motion.div 
                  key={index} 
                  className="flex items-start p-8 attractive-card shadow-lg attractive-lift border-0 group"
                  variants={cardVariants}
                  whileHover={{ scale: 1.02 }}
                >
                  <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center mr-6 shadow-lg group-hover:scale-110 transition-transform duration-300">
                    <achievement.icon className="h-8 w-8 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-xl font-bold text-slate-900">{achievement.title}</h3>
                      <Badge className="bg-green-100 text-green-700 text-xs">{achievement.year}</Badge>
                    </div>
                    <p className="text-slate-700 leading-relaxed">{achievement.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Enhanced CTA Section */}
      <section className="py-24 relative">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.5 }}
            variants={{
              hidden: {opacity:0, scale:0.95},
              visible: {opacity:1, scale:1, transition:{duration:1}}
            }}
          >
            <div className="attractive-card p-20 shadow-2xl border-0 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-600/5 via-indigo-600/5 to-purple-600/5"></div>
              <div className="relative z-10">
                <h2 className="text-4xl md:text-6xl font-bold text-slate-900 mb-8">
                  Ready to Work With
                  <span className="block bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                    Industry Leaders?
                  </span>
                </h2>
                <p className="text-xl text-slate-700 mb-12 max-w-3xl mx-auto leading-relaxed">
                  Join hundreds of satisfied clients who have transformed their business 
                  with our innovative technology solutions and expert guidance.
                </p>
                <div className="flex flex-col sm:flex-row gap-8 justify-center">
                  <Link to={createPageUrl("Contact")}>
                    <Button size="lg" className="gradient-primary text-white hover:shadow-xl transition-all duration-300 hover:scale-105 px-12 py-6 text-xl rounded-2xl">
                      Start Your Project
                      <ArrowRight className="ml-3 h-7 w-7" />
                    </Button>
                  </Link>
                  <Link to={createPageUrl("Portfolio")}>
                    <Button variant="outline" size="lg" className="border-2 border-blue-300 text-blue-700 hover:bg-blue-50 hover:border-blue-400 transition-all duration-300 px-12 py-6 text-xl rounded-2xl">
                      View Our Portfolio
                      <Sparkles className="ml-3 h-7 w-7" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
