
import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import {
  ArrowRight, Code, Smartphone, Shield, Cloud, Network, Server,
  Star, CheckCircle, TrendingUp, Users, Lightbulb, Zap, Heart,
  Sparkles, Award, Target, Eye, Rocket
} from "lucide-react";
import HeroSection from "../components/home/HeroSection";
import AnimatedCounter from "../components/home/AnimatedCounter";
import ContactForm from "../components/home/ContactForm";

export default function Home() {
  const whyChooseUs = [
    {
      icon: Lightbulb,
      title: "Innovative Solutions",
      description: "We leverage cutting-edge technology and creative thinking to deliver solutions that set you apart from the competition.",
      color: "from-cyan-500 to-blue-600"
    },
    {
      icon: Zap,
      title: "Lightning Fast Delivery",
      description: "Our streamlined development process and expert team ensure rapid delivery without compromising on quality.",
      color: "from-purple-500 to-pink-600"
    },
    {
      icon: Heart,
      title: "Client-Focused Approach",
      description: "Your success is our priority. We work closely with you to understand your needs and exceed expectations.",
      color: "from-pink-500 to-orange-600"
    },
    {
      icon: Shield,
      title: "Reliable & Secure",
      description: "Enterprise-grade security and 99.9% uptime guarantee ensure your business operations run smoothly 24/7.",
      color: "from-green-500 to-emerald-600"
    }
  ];

  const featuredServices = [
    {
      icon: Code,
      title: "Web Development",
      description: "Custom websites and web applications built with modern technologies and responsive design.",
      color: "from-blue-500 to-indigo-600",
      features: ["React & Next.js", "Responsive Design", "SEO Optimized", "Fast Performance"]
    },
    {
      icon: Smartphone,
      title: "App Development",
      description: "Native and cross-platform mobile applications for iOS and Android with stunning UI/UX.",
      color: "from-purple-500 to-violet-600",
      features: ["iOS & Android", "Cross-platform", "UI/UX Design", "App Store Ready"]
    },
    {
      icon: Shield,
      title: "Cybersecurity",
      description: "Comprehensive security solutions to protect your digital assets from cyber threats.",
      color: "from-green-500 to-emerald-600",
      features: ["Security Audits", "Threat Protection", "Compliance", "24/7 Monitoring"]
    },
    {
      icon: Cloud,
      title: "Cloud Solutions",
      description: "Scalable cloud infrastructure and migration services for optimal performance.",
      color: "from-sky-500 to-blue-600",
      features: ["Cloud Migration", "Auto Scaling", "Backup & Recovery", "Cost Optimization"]
    },
    {
      icon: Network,
      title: "IT Networking",
      description: "Professional network setup and maintenance for seamless business operations.",
      color: "from-orange-500 to-red-600",
      features: ["Network Design", "Security Setup", "Monitoring", "24/7 Support"]
    },
    {
      icon: Server,
      title: "DevOps Services",
      description: "Streamlined deployment and infrastructure management for continuous delivery.",
      color: "from-red-500 to-pink-600",
      features: ["CI/CD Pipelines", "Automation", "Monitoring", "Scalability"]
    }
  ];

  const stats = [
    {
      icon: Award,
      number: 15,
      suffix: "+",
      label: "Years Experience",
      glow: "from-yellow-500 to-orange-600"
    },
    {
      icon: CheckCircle,
      number: 500,
      suffix: "+",
      label: "Projects Completed",
      glow: "from-green-500 to-emerald-600"
    },
    {
      icon: TrendingUp,
      number: 99.9,
      suffix: "%",
      label: "Client Satisfaction",
      glow: "from-blue-500 to-cyan-600"
    },
    {
      icon: Users,
      number: 200,
      suffix: "+",
      label: "Happy Clients",
      glow: "from-purple-500 to-pink-600"
    },
  ];

  // Updated Portfolio with RoyalTech Projects
  const portfolio = [
    {
      title: "Alpha Platform",
      category: "Web Development",
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=2940&auto=format&fit=crop",
      gradient: "from-cyan-500/90 to-blue-600/90",
      tech: ["React", "Node.js", "MongoDB", "AWS"],
      results: "300% performance boost"
    },
    {
      title: "Kamistor E-Commerce",
      category: "Web Development",
      image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?q=80&w=2940&auto=format&fit=crop",
      gradient: "from-purple-500/90 to-pink-600/90",
      tech: ["Next.js", "Stripe", "PostgreSQL", "Redis"],
      results: "250% sales increase"
    },
    {
      title: "Homebit Smart App",
      category: "Mobile Development",
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?q=80&w=2940&auto=format&fit=crop",
      gradient: "from-green-500/90 to-emerald-600/90",
      tech: ["React Native", "IoT", "Firebase", "ML"],
      results: "100K+ downloads"
    },
    {
      title: "Koor Food Delivery",
      category: "Mobile Development",
      image: "https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?q=80&w=2940&auto=format&fit=crop",
      gradient: "from-orange-500/90 to-red-600/90",
      tech: ["Flutter", "Google Maps", "Payment Gateway"],
      results: "50K+ active users"
    },
    {
      title: "Bost Analytics",
      category: "Web Development",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2940&auto=format&fit=crop",
      gradient: "from-blue-500/90 to-indigo-600/90",
      tech: ["Vue.js", "Python", "Machine Learning"],
      results: "Real-time insights"
    },
    {
      title: "Half Price Marketplace",
      category: "E-Commerce",
      image: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?q=80&w=2940&auto=format&fit=crop",
      gradient: "from-teal-500/90 to-cyan-600/90",
      tech: ["React", "Microservices", "Docker"],
      results: "1M+ transactions"
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: "easeOut",
      },
    },
  };

  return (
    <>
      <HeroSection />
      
      {/* Why Choose RoyalTech Section */}
      <section className="py-24 relative bg-gradient-to-br from-white via-blue-50/30 to-indigo-50/20">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-20 left-20 w-32 h-32 bg-blue-200 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-20 w-40 h-40 bg-indigo-200 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={containerVariants}
          >
            <motion.div className="text-center mb-20" variants={cardVariants}>
              <div className="inline-flex items-center px-6 py-3 bg-blue-100 text-blue-700 rounded-full font-semibold text-lg mb-8">
                Why Choose RoyalTech?
              </div>
              <h2 className="text-5xl md:text-7xl font-bold mb-8">
                <span className="text-slate-900">Leading Technology</span>
                <br />
                <span className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent">
                  Innovation Partner
                </span>
              </h2>
              <p className="text-2xl text-slate-700 max-w-4xl mx-auto leading-relaxed">
                We deliver cutting-edge technology solutions that drive real business results and accelerate your digital transformation journey.
              </p>
            </motion.div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-8">
              {whyChooseUs.map((item, index) => (
                <motion.div key={index} variants={cardVariants}>
                  <Card className="attractive-card h-full text-center p-8 attractive-lift border-0 shadow-lg">
                    <CardContent className="p-0">
                      <div className={`inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br ${item.color} mb-8 shadow-xl`}>
                        <item.icon className="h-10 w-10 text-white" />
                      </div>
                      <h3 className="text-2xl font-bold text-slate-900 mb-6">{item.title}</h3>
                      <p className="text-slate-600 leading-relaxed text-lg">{item.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Services */}
      <section className="py-24 relative bg-gradient-to-br from-slate-50 via-blue-50/50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={containerVariants}
          >
            <motion.div className="text-center mb-20" variants={cardVariants}>
              <div className="inline-flex items-center px-6 py-3 bg-indigo-100 text-indigo-700 rounded-full font-semibold text-lg mb-8">
                Our Services
              </div>
              <h2 className="text-5xl md:text-7xl font-bold mb-8">
                <span className="text-slate-900">Comprehensive</span>
                <br />
                <span className="bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 bg-clip-text text-transparent">
                  Tech Solutions
                </span>
              </h2>
              <p className="text-2xl text-slate-700 max-w-4xl mx-auto leading-relaxed">
                From web development to cybersecurity, we provide end-to-end technology services for modern businesses.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
              {featuredServices.map((service, index) => (
                <motion.div key={index} variants={cardVariants}>
                  <Card className="attractive-card h-full attractive-lift border-0 shadow-lg overflow-hidden">
                    <CardContent className="p-8">
                      <div className={`inline-flex items-center justify-center w-18 h-18 rounded-2xl bg-gradient-to-br ${service.color} mb-8 shadow-xl`}>
                        <service.icon className="h-9 w-9 text-white" />
                      </div>
                      <h3 className="text-2xl font-bold text-slate-900 mb-6">{service.title}</h3>
                      <p className="text-slate-600 mb-8 text-lg leading-relaxed">{service.description}</p>
                      <div className="space-y-3">
                        {service.features.map((feature, i) => (
                          <div key={i} className="flex items-center text-slate-600">
                            <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                            <span className="text-lg">{feature}</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            <motion.div className="text-center mt-16" variants={cardVariants}>
              <Link to={createPageUrl("Services")}>
                <Button size="lg" className="gradient-primary text-white px-12 py-6 text-xl rounded-2xl hover:scale-105 transition-all duration-300 shadow-xl">
                  View All Services
                  <ArrowRight className="ml-3 h-7 w-7" />
                </Button>
              </Link>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-24 relative bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0" style={{
            backgroundImage: `url("data:image/svg+xml,${encodeURIComponent('<svg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="evenodd"><g fill="#ffffff" fill-opacity="0.1"><circle cx="30" cy="30" r="2"/></g></g></svg>')}")`
          }}></div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={containerVariants}
          >
            {stats.map((stat, index) => (
              <motion.div key={index} className="text-center" variants={cardVariants}>
                <div className="bg-white/10 backdrop-blur-md rounded-3xl p-10 attractive-lift border border-white/20">
                  <div className={`inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br ${stat.glow} mb-8 shadow-2xl`}>
                    <stat.icon className="h-10 w-10 text-white" />
                  </div>
                  <div className="text-5xl md:text-6xl font-bold text-white mb-4">
                    <AnimatedCounter to={stat.number} isPercentage={stat.suffix === '%'} />
                    {stat.suffix}
                  </div>
                  <div className="text-blue-100 font-semibold text-xl">{stat.label}</div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Portfolio Preview */}
      <section className="py-24 relative bg-gradient-to-br from-slate-50 via-blue-50/30 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={containerVariants}
          >
            <motion.div className="text-center mb-20" variants={cardVariants}>
              <div className="inline-flex items-center px-6 py-3 bg-emerald-100 text-emerald-700 rounded-full font-semibold text-lg mb-8">
                Our Portfolio
              </div>
              <h2 className="text-5xl md:text-7xl font-bold mb-8">
                <span className="text-slate-900">Success</span>
                <br />
                <span className="bg-gradient-to-r from-emerald-600 via-teal-600 to-blue-600 bg-clip-text text-transparent">
                  Stories
                </span>
              </h2>
              <p className="text-2xl text-slate-700 max-w-4xl mx-auto leading-relaxed">
                Discover our latest projects that showcase innovation, excellence, and measurable business impact.
              </p>
            </motion.div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
              {portfolio.map((item, index) => (
                <motion.div key={index} variants={cardVariants}>
                  <Card className="attractive-card overflow-hidden attractive-lift border-0 shadow-lg">
                    <div className="relative h-64">
                      <img
                        src={item.image}
                        alt={item.title}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      />
                      <div className={`absolute inset-0 bg-gradient-to-t ${item.gradient}`}></div>
                      <div className="absolute top-4 left-4">
                        <span className="px-4 py-2 bg-white/20 backdrop-blur-md text-white text-sm font-semibold rounded-full">
                          {item.category}
                        </span>
                      </div>
                    </div>
                    <CardContent className="p-8">
                      <h3 className="text-2xl font-bold text-slate-900 mb-6">{item.title}</h3>
                      <div className="flex flex-wrap gap-2 mb-6">
                        {item.tech.map((tech, i) => (
                          <span key={i} className="px-4 py-2 bg-blue-50 text-blue-700 rounded-full text-sm font-medium border border-blue-200">
                            {tech}
                          </span>
                        ))}
                      </div>
                      <div className="text-green-600 font-bold text-lg">{item.results}</div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
            
            <motion.div className="text-center mt-16" variants={cardVariants}>
              <Link to={createPageUrl("Portfolio")}>
                <Button size="lg" className="bg-gradient-to-r from-emerald-600 via-teal-600 to-blue-600 text-white px-12 py-6 text-xl rounded-2xl hover:scale-105 transition-all duration-300 shadow-xl">
                  View Full Portfolio
                  <Rocket className="ml-3 h-7 w-7" />
                </Button>
              </Link>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Contact Form */}
      <ContactForm />

      {/* Final CTA Section */}
      <section className="py-24 relative bg-gradient-to-br from-slate-50 via-blue-50/30 to-indigo-50/20">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.5 }}
            variants={{
              hidden: {opacity:0, scale:0.95},
              visible: {opacity:1, scale:1, transition:{duration:1}}
            }}
          >
            <div className="attractive-card p-20 shadow-2xl border-0 overflow-hidden relative">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-600/5 via-indigo-600/5 to-purple-600/5"></div>
              <div className="relative z-10">
                <h2 className="text-5xl md:text-7xl font-bold text-slate-900 mb-8">
                  Ready to Build
                  <br />
                  <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                    Something Amazing?
                  </span>
                </h2>
                <p className="text-2xl text-slate-700 mb-12 max-w-4xl mx-auto leading-relaxed">
                  Let's discuss your project and create a solution that exceeds your expectations and drives real business growth.
                </p>
                <div className="flex flex-col lg:flex-row gap-8 justify-center">
                  <Link to={createPageUrl("Contact")}>
                    <Button size="lg" className="gradient-primary text-white px-12 py-6 text-xl rounded-2xl hover:scale-105 transition-all duration-300 shadow-xl">
                      Start Your Project
                      <Rocket className="ml-3 h-7 w-7" />
                    </Button>
                  </Link>
                  <Link to={createPageUrl("About")}>
                    <Button variant="outline" size="lg" className="border-2 border-blue-300 text-blue-700 hover:bg-blue-50 hover:border-blue-400 px-12 py-6 text-xl rounded-2xl transition-all duration-300">
                      Learn More About Us
                      <Sparkles className="ml-3 h-7 w-7" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </>
  );
}
