
import React, { useState } from "react";
import { Contact as ContactEntity } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import {
  Phone,
  Mail,
  MapPin,
  Clock,
  Send,
  CheckCircle,
  ArrowRight } from
"lucide-react";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    service_interest: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Save to database only
      await ContactEntity.create(formData);

      setIsSubmitted(true);
      setFormData({
        name: "",
        email: "",
        phone: "",
        company: "",
        service_interest: "",
        message: ""
      });
    } catch (error) {
      console.error("Error submitting form:", error);
    }

    setIsSubmitting(false);
  };

  const contactInfo = [
  {
    icon: Phone,
    title: "Phone",
    details: ["+1 (916) 465-1850", "+1 (916) 465-1850"],
    color: "from-blue-500 to-blue-600"
  },
  {
    icon: Mail,
    title: "Email",
    details: ["info@royatech.com", "support@royatech.com"],
    color: "from-green-500 to-green-600"
  },
  {
    icon: MapPin,
    title: "Address",
    details: ["1201 Fulton Ave", "Sacramento, CA 95825"],
    color: "from-purple-500 to-purple-600"
  },
  {
    icon: Clock,
    title: "Business Hours",
    details: ["Mon - Fri: 9:00 AM - 6:00 PM", "Sat: 10:00 AM - 2:00 PM"],
    color: "from-orange-500 to-orange-600"
  }];


  const services = [
  { value: "web_development", label: "Web Development" },
  { value: "app_development", label: "App Development" },
  { value: "hosting", label: "Web Hosting & Domain" },
  { value: "networking", label: "Computer Networking" },
  { value: "security", label: "CCTV & Security Systems" },
  { value: "consulting", label: "IT Consulting" },
  { value: "cloud", label: "Cloud Solutions" },
  { value: "iot", label: "IoT & Smart Home" },
  { value: "other", label: "Other" }];


  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 50, scale: 0.95 },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        duration: 0.8,
        ease: "easeOut"
      }
    }
  };

  const floatingAnimation = {
    y: [-10, 10],
    transition: {
      duration: 3,
      repeat: Infinity,
      repeatType: "reverse",
      ease: "easeInOut"
    }
  };

  return (
    <div className="animate-fade-in relative">
      {/* Floating Background Elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <motion.div
          className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl"
          animate={floatingAnimation} />

        <motion.div
          className="absolute top-3/4 right-1/4 w-72 h-72 bg-purple-500/5 rounded-full blur-3xl"
          animate={{
            y: [10, -10],
            transition: {
              duration: 4,
              repeat: Infinity,
              repeatType: "reverse",
              ease: "easeInOut"
            }
          }} />

        <motion.div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-blue-500/5 rounded-full blur-3xl"
          animate={{
            y: [-15, 15],
            transition: {
              duration: 5,
              repeat: Infinity,
              repeatType: "reverse",
              ease: "easeInOut"
            }
          }} />

      </div>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-32">
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 z-10">
          <motion.div
            className="text-center"
            initial="hidden"
            animate="visible"
            variants={containerVariants}>

            <motion.div variants={cardVariants}>
              <Badge className="mb-6 bg-cyan-500/10 text-cyan-300 hover:bg-cyan-500/20 transition-colors border border-cyan-500/20">
                Get In Touch
              </Badge>
            </motion.div>
            <motion.h1
              className="text-4xl md:text-6xl font-bold text-white mb-8 leading-tight"
              variants={cardVariants}>

              Let's Start Your
              <span className="block gradient-text">Digital Journey</span>
            </motion.h1>
            <motion.p className="text-4xl mb-10 mx-auto md:text-xl max-w-3xl leading-relaxed"

            variants={cardVariants}>Ready to transform your business with cutting-edge technology? Contact us today for a free consultation and discover how we can help you achieve your goals.



            </motion.p>
          </motion.div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={containerVariants}>

            {contactInfo.map((info, index) =>
            <motion.div key={index} variants={cardVariants}>
                <Card className="hover-lift bg-slate-800/30 border border-white/10 backdrop-blur-xl text-center hover:shadow-[0_0_35px_rgba(6,182,212,0.3)] hover:border-cyan-400/60 transition-all duration-500">
                  <CardContent className="bg-slate-500 m-0 p-8">
                    <motion.div
                    className={`inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br ${info.color} mb-6`}
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    transition={{ duration: 0.3 }}>

                      <info.icon className="h-8 w-8 text-white" />
                    </motion.div>
                    <h3 className="text-xl font-semibold text-white mb-3">{info.title}</h3>
                    <div className="space-y-1">
                      {info.details.map((detail, detailIndex) =>
                    <p key={detailIndex} className="text-slate-300">{detail}</p>
                    )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </motion.div>

          {/* Contact Form and Map */}
          <motion.div
            className="grid grid-cols-1 lg:grid-cols-2 gap-12"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={containerVariants}>

            {/* Contact Form */}
            <motion.div variants={cardVariants}>
              <Card className="bg-slate-800/30 border border-cyan-500/20 backdrop-blur-xl shadow-[0_0_35px_rgba(6,182,212,0.3)]">
                <CardContent className="bg-slate-500 p-8">
                  <h2 className="text-2xl font-bold text-white mb-6">Send Us a Message</h2>
                  
                  {isSubmitted ?
                  <div className="text-center py-8">
                      <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <CheckCircle className="h-8 w-8 text-green-600" />
                      </div>
                      <h3 className="text-xl font-semibold text-white mb-2">Message Sent!</h3>
                      <p className="text-slate-300 mb-6">
                        Thank you for your message. We'll get back to you within 24 hours.
                      </p>
                      <Button onClick={() => setIsSubmitted(false)} variant="outline" className="border-cyan-500/50 text-cyan-300 hover:bg-cyan-500/20 hover:border-cyan-400 transition-all duration-300 backdrop-blur-md">
                        Send Another Message
                      </Button>
                    </div> :

                  <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="input-glow-group">
                          <Label htmlFor="name" className="text-slate-300">Full Name *</Label>
                          <Input
                          id="name"
                          value={formData.name}
                          onChange={(e) => handleInputChange("name", e.target.value)}
                          required
                          className="mt-1 bg-slate-900/50 border-slate-700 text-white transition-all duration-300" />

                        </div>
                        <div className="input-glow-group">
                          <Label htmlFor="email" className="text-slate-300">Email Address *</Label>
                          <Input
                          id="email"
                          type="email"
                          value={formData.email}
                          onChange={(e) => handleInputChange("email", e.target.value)}
                          required
                          className="mt-1 bg-slate-900/50 border-slate-700 text-white transition-all duration-300" />

                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="input-glow-group">
                          <Label htmlFor="phone" className="text-slate-300">Phone Number</Label>
                          <Input
                          id="phone"
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => handleInputChange("phone", e.target.value)}
                          className="mt-1 bg-slate-900/50 border-slate-700 text-white transition-all duration-300" />

                        </div>
                        <div className="input-glow-group">
                          <Label htmlFor="company" className="text-slate-300">Company Name</Label>
                          <Input
                          id="company"
                          value={formData.company}
                          onChange={(e) => handleInputChange("company", e.target.value)}
                          className="mt-1 bg-slate-900/50 border-slate-700 text-white transition-all duration-300" />

                        </div>
                      </div>

                      <div>
                        <Label htmlFor="service" className="text-slate-300">Service of Interest</Label>
                        <Select
                        value={formData.service_interest}
                        onValueChange={(value) => handleInputChange("service_interest", value)}>

                          <SelectTrigger className="mt-1 bg-slate-900/50 border-slate-700 text-white">
                            <SelectValue placeholder="Select a service" />
                          </SelectTrigger>
                          <SelectContent className="bg-slate-800 border-slate-700 text-white">
                            {services.map((service) =>
                          <SelectItem key={service.value} value={service.value} className="focus:bg-slate-700">
                                {service.label}
                              </SelectItem>
                          )}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="input-glow-group">
                        <Label htmlFor="message" className="text-slate-300">Message *</Label>
                        <Textarea
                        id="message"
                        value={formData.message}
                        onChange={(e) => handleInputChange("message", e.target.value)}
                        placeholder="Tell us about your project requirements..."
                        className="mt-1 h-32 bg-slate-900/50 border-slate-700 text-white transition-all duration-300"
                        required />

                      </div>

                      <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full gradient-accent-bg text-white hover:shadow-2xl hover:shadow-cyan-500/30 transition-all duration-300 pulse-glow-button">

                        {isSubmitting ? "Sending..." : "Send Message"}
                        <Send className="ml-2 h-4 w-4" />
                      </Button>
                    </form>
                  }
                </CardContent>
              </Card>
            </motion.div>

            {/* Map and Additional Info */}
            <div className="space-y-8">
              <motion.div variants={cardVariants}>
                <Card className="bg-slate-800/30 border border-white/10 backdrop-blur-xl overflow-hidden hover:shadow-[0_0_35px_rgba(6,182,212,0.3)] hover:border-cyan-400/60 transition-all duration-500">
                  <div className="bg-slate-500 text-slate-50 h-64 flex items-center justify-center">
                    <div className="text-center">
                      <MapPin className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-slate-300">Interactive Map Coming Soon</p>
                      <p className="text-sm text-slate-400">1201 Fulton Ave, Sacramento, CA 95825</p>
                    </div>
                  </div>
                </Card>
              </motion.div>

              <motion.div variants={cardVariants}>
                <Card className="bg-slate-800/30 border border-white/10 backdrop-blur-xl hover:shadow-[0_0_35px_rgba(6,182,212,0.3)] hover:border-cyan-400/60 transition-all duration-500">
                  <CardContent className="bg-slate-500 text-slate-50 p-8">
                    <h3 className="text-xl font-semibold text-white mb-4">Why Choose ROYA Tech?</h3>
                    <ul className="space-y-3">
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-3 flex-shrink-0" />
                        <span className="text-slate-300">24/7 Technical Support</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-3 flex-shrink-0" />
                        <span className="text-slate-300">Free Initial Consultation</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-3 flex-shrink-0" />
                        <span className="text-slate-300">Competitive Pricing</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-3 flex-shrink-0" />
                        <span className="text-slate-300">Proven Track Record</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-3 flex-shrink-0" />
                        <span className="text-slate-300">Latest Technology Stack</span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900 via-blue-900/70 to-slate-900"></div>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.5 }}
            variants={{
              hidden: { opacity: 0, scale: 0.9 },
              visible: { opacity: 1, scale: 1, transition: { duration: 0.8 } }
            }}>

            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Ready to Transform Your Business?
            </h2>
            <p className="text-lg text-slate-300 mb-10 max-w-2xl mx-auto">
              Don't wait - start your digital transformation journey today. 
              Our team of experts is ready to help you succeed.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="gradient-accent-bg text-white hover:shadow-2xl hover:shadow-cyan-500/30 transition-all duration-300 hover:scale-105 pulse-glow-button px-8 py-4">
                Schedule Free Consultation
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button variant="outline" size="lg" className="border-cyan-500/50 text-cyan-300 hover:bg-cyan-500/20 hover:border-cyan-400 transition-all duration-300 backdrop-blur-md px-8 py-4">
                <Phone className="mr-2 h-5 w-5" />
                Call Us Now
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>);

}
