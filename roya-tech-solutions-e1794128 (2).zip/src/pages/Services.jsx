
import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import {
  Code,
  Smartphone,
  Server,
  Network,
  Shield,
  MessageSquare,
  Cloud,
  Monitor,
  ArrowRight,
  CheckCircle,
  Puzzle,
  Star,
  Zap,
  Award,
  Target
} from "lucide-react";

export default function Services() {
  const services = [
    {
      icon: Code,
      title: "Web Development",
      description: "Custom websites and web applications built with modern technologies and responsive design.",
      features: [
        "Responsive Design",
        "E-commerce Solutions",
        "CMS Development",
        "API Integration",
        "Performance Optimization"
      ],
      technologies: ["React", "Node.js", "PHP", "Python", "WordPress"],
      color: "from-blue-500 to-indigo-600"
    },
    {
      icon: Smartphone,
      title: "App Development",
      description: "Native and cross-platform mobile applications for iOS and Android with stunning UI/UX.",
      features: [
        "iOS & Android Apps",
        "Cross-platform Solutions",
        "UI/UX Design",
        "App Store Optimization",
        "Maintenance & Updates"
      ],
      technologies: ["React Native", "Flutter", "Swift", "Kotlin", "Xamarin"],
      color: "from-purple-500 to-pink-600"
    },
    {
      icon: Server,
      title: "Web Hosting & Domain",
      description: "Reliable hosting solutions with 99.9% uptime guarantee and comprehensive domain services.",
      features: [
        "Shared Hosting",
        "VPS Hosting",
        "Dedicated Servers",
        "Domain Registration",
        "SSL Certificates"
      ],
      technologies: ["Linux", "Windows", "cPanel", "Plesk", "CloudFlare"],
      color: "from-green-500 to-emerald-600"
    },
    {
      icon: Network,
      title: "Computer Networking",
      description: "Comprehensive LAN/WAN solutions for businesses with professional setup and maintenance.",
      features: [
        "Network Design",
        "LAN/WAN Setup",
        "Router Configuration",
        "Network Security",
        "Monitoring & Maintenance"
      ],
      technologies: ["Cisco", "Juniper", "Ubiquiti", "Mikrotik", "Fortinet"],
      color: "from-indigo-500 to-blue-600"
    },
    {
      icon: Monitor,
      title: "CCTV & Surveillance",
      description: "Advanced security camera systems and surveillance solutions for comprehensive monitoring.",
      features: [
        "IP Camera Installation",
        "DVR/NVR Systems",
        "Remote Monitoring",
        "Motion Detection",
        "Mobile Access"
      ],
      technologies: ["Hikvision", "Dahua", "Axis", "Bosch", "Avigilon"],
      color: "from-red-500 to-orange-600"
    },
    {
      icon: MessageSquare,
      title: "IT Consulting",
      description: "Strategic IT consulting to optimize your technology infrastructure and digital transformation.",
      features: [
        "IT Strategy Planning",
        "System Integration",
        "Technology Audits",
        "Digital Transformation",
        "24/7 Support"
      ],
      technologies: ["ITIL", "Agile", "DevOps", "Cloud Migration", "Automation"],
      color: "from-yellow-500 to-amber-600"
    },
    {
      icon: Cloud,
      title: "Cloud Solutions",
      description: "Scalable cloud infrastructure and migration services for optimal performance and cost efficiency.",
      features: [
        "Cloud Migration",
        "Infrastructure as Code",
        "Auto Scaling",
        "Backup & Recovery",
        "Cost Optimization"
      ],
      technologies: ["AWS", "Azure", "Google Cloud", "Docker", "Kubernetes"],
      color: "from-cyan-500 to-blue-600"
    },
    {
      icon: Shield,
      title: "Cybersecurity",
      description: "Comprehensive security solutions to protect your digital assets from cyber threats and vulnerabilities.",
      features: [
        "Security Assessments",
        "Penetration Testing",
        "Firewall Configuration",
        "Endpoint Protection",
        "Security Training"
      ],
      technologies: ["Palo Alto", "Checkpoint", "Symantec", "CrowdStrike", "Splunk"],
      color: "from-orange-500 to-red-600"
    },
    {
      icon: Puzzle,
      title: "IoT & Smart Home",
      description: "Innovative solutions to connect and automate your environment, creating intelligent and responsive systems.",
      features: [
        "Smart Device Integration",
        "Home & Office Automation",
        "Custom IoT Platforms",
        "Real-time Data Analytics",
        "Secure IoT Networks"
      ],
      technologies: ["MQTT", "AWS IoT", "Raspberry Pi", "Arduino", "Zigbee"],
      color: "from-pink-500 to-purple-600"
    }
  ];

  const processSteps = [
    {
      step: "01",
      title: "Discovery & Analysis",
      description: "We analyze your requirements, business objectives, and technical constraints to understand your unique needs and goals.",
      icon: "🔍",
      color: "from-blue-500 to-indigo-600"
    },
    {
      step: "02",
      title: "Strategic Planning",
      description: "We create a comprehensive project roadmap with clear milestones, timelines, and deliverables tailored to your vision.",
      icon: "📋",
      color: "from-purple-500 to-pink-600"
    },
    {
      step: "03",
      title: "Design & Development",
      description: "Our expert team builds your solution using industry best practices, modern technologies, and scalable architecture.",
      icon: "⚙️",
      color: "from-green-500 to-emerald-600"
    },
    {
      step: "04",
      title: "Quality Assurance",
      description: "Rigorous testing across multiple environments ensures flawless functionality, security, and optimal performance.",
      icon: "🧪",
      color: "from-orange-500 to-red-600"
    },
    {
      step: "05",
      title: "Deployment & Launch",
      description: "Seamless deployment with minimal downtime, comprehensive monitoring, and immediate performance optimization.",
      icon: "🚀",
      color: "from-cyan-500 to-blue-600"
    },
    {
      step: "06",
      title: "Ongoing Support",
      description: "Continuous maintenance, updates, and 24/7 support to ensure your solution evolves with your business needs.",
      icon: "🛠️",
      color: "from-indigo-500 to-purple-600"
    }
  ];

  const whyChooseUs = [
    {
      icon: Award,
      title: "15+ Years Experience",
      description: "Industry-leading expertise with proven track record",
      stat: "500+ Projects"
    },
    {
      icon: Star,
      title: "99.9% Client Satisfaction",
      description: "Exceptional service quality and client relationships",
      stat: "200+ Clients"
    },
    {
      icon: Shield,
      title: "Enterprise Security",
      description: "ISO 27001 certified with military-grade protection",
      stat: "Zero Breaches"
    },
    {
      icon: Zap,
      title: "Rapid Deployment",
      description: "Agile development with fastest time-to-market",
      stat: "2x Faster"
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 30, scale: 0.95 },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        duration: 0.8,
        ease: "easeOut"
      }
    }
  };

  return (
    <div className="bg-gradient-to-br from-slate-50 via-blue-50/30 to-indigo-50/20">

      {/* Enhanced Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-32 bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,${encodeURIComponent('<svg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="evenodd"><g fill="#ffffff" fill-opacity="0.1"><circle cx="30" cy="30" r="2"/></g></g></svg>')}")`,
          opacity: 0.2
        }}></div>
        
        {/* Floating Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          {[...Array(15)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-3 h-3 bg-white/20 rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                y: [0, -30, 0],
                opacity: [0, 1, 0],
                scale: [1, 1.5, 1],
              }}
              transition={{
                duration: 3 + Math.random() * 2,
                repeat: Infinity,
                delay: Math.random() * 2,
                ease: "easeInOut"
              }}
            />
          ))}
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 z-10">
          <motion.div
            className="text-center"
            initial="hidden"
            animate="visible"
            variants={containerVariants}
          >
            <motion.div variants={cardVariants}>
              <div className="inline-flex items-center px-6 py-3 bg-white/20 backdrop-blur-md text-white rounded-full font-semibold text-lg mb-8">
                <Target className="w-5 h-5 mr-2" />
                Our Services
              </div>
            </motion.div>
            <motion.h1
              className="text-5xl md:text-7xl font-bold text-white mb-10 leading-tight"
              variants={cardVariants}
            >
              Comprehensive
              <span className="block bg-gradient-to-r from-cyan-300 to-blue-300 bg-clip-text text-transparent">Technology Solutions</span>
            </motion.h1>
            <motion.p
              className="text-xl md:text-2xl text-blue-100 mb-12 max-w-4xl mx-auto leading-relaxed"
              variants={cardVariants}
            >
              From web development to cybersecurity, we provide end-to-end technology services
              that drive innovation and accelerate your business growth with measurable results.
            </motion.p>
          </motion.div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-24 relative bg-gradient-to-r from-slate-100 via-blue-50 to-indigo-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={containerVariants}
          >
            <motion.div className="text-center mb-20" variants={cardVariants}>
              <div className="inline-flex items-center px-6 py-3 bg-blue-100 text-blue-700 rounded-full font-semibold text-lg mb-8">
                <Award className="w-5 h-5 mr-2" />
                Why Choose ROYA Tech?
              </div>
              <h2 className="text-4xl md:text-6xl font-bold text-slate-900 mb-6">
                Industry Leading Excellence
              </h2>
              <p className="text-xl text-slate-700 max-w-4xl mx-auto leading-relaxed">
                We combine years of expertise with cutting-edge technology to deliver solutions that exceed expectations.
              </p>
            </motion.div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {whyChooseUs.map((item, index) => (
                <motion.div key={index} variants={cardVariants}>
                  <Card className="attractive-card text-center h-full attractive-lift border-0 shadow-lg">
                    <CardContent className="p-8">
                      <motion.div 
                        className="inline-flex items-center justify-center w-18 h-18 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 mb-6 shadow-xl"
                        whileHover={{ scale: 1.1, rotate: 5 }}
                        transition={{ duration: 0.3 }}
                      >
                        <item.icon className="h-9 w-9 text-white" />
                      </motion.div>
                      <div className="text-3xl font-bold text-blue-600 mb-2">{item.stat}</div>
                      <h3 className="text-xl font-bold text-slate-900 mb-4">{item.title}</h3>
                      <p className="text-slate-700 leading-relaxed">{item.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-24 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-20">
            <div className="inline-flex items-center px-6 py-3 bg-indigo-100 text-indigo-700 rounded-full font-semibold text-lg mb-8">
              <Code className="w-5 h-5 mr-2" />
              Our Solutions
            </div>
            <h2 className="text-4xl md:text-6xl font-bold text-slate-900 mb-6">
              Transform Your Business
            </h2>
            <p className="text-xl text-slate-700 max-w-4xl mx-auto leading-relaxed">
              Choose from our comprehensive range of technology services designed to accelerate your digital transformation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {services.map((service, index) => (
              <Card key={index} className="attractive-card h-full attractive-lift border-0 shadow-lg overflow-hidden group">
                <CardContent className="p-8">
                  <div
                    className={`inline-flex items-center justify-center w-18 h-18 rounded-2xl bg-gradient-to-br ${service.color} mb-8 shadow-xl group-hover:scale-110 transition-all duration-300`}
                  >
                    <service.icon className="h-9 w-9 text-white" />
                  </div>

                  <h3 className="text-2xl font-bold text-slate-900 mb-4 group-hover:text-blue-600 transition-colors duration-300">{service.title}</h3>
                  <p className="text-slate-700 mb-6 leading-relaxed text-lg">{service.description}</p>

                  <div className="mb-8">
                    <h4 className="font-bold text-slate-900 mb-4 text-lg">Key Features:</h4>
                    <ul className="space-y-3">
                      {service.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-center text-slate-700">
                          <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="mb-8">
                    <h4 className="font-bold text-slate-900 mb-4 text-lg">Technologies:</h4>
                    <div className="flex flex-wrap gap-2">
                      {service.technologies.map((tech, techIndex) => (
                        <Badge key={techIndex} variant="outline" className="text-sm border-blue-200 text-blue-700 bg-blue-50 hover:bg-blue-100">
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <Link to={createPageUrl("Contact")}>
                    <Button className="w-full gradient-primary text-white hover:shadow-xl transition-all duration-300 hover:scale-105 py-4 text-lg rounded-xl group">
                      Get Started Today
                      <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Enhanced Process Section */}
      <section className="py-24 relative bg-gradient-to-r from-slate-100 via-blue-50 to-indigo-50 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={containerVariants}
          >
            <motion.div className="text-center mb-20" variants={cardVariants}>
              <div className="inline-flex items-center px-6 py-3 bg-emerald-100 text-emerald-700 rounded-full font-semibold text-lg mb-8">
                <Zap className="w-5 h-5 mr-2" />
                Our Process
              </div>
              <h2 className="text-4xl md:text-6xl font-bold text-slate-900 mb-6">
                How We Deliver Excellence
              </h2>
              <p className="text-xl text-slate-700 max-w-4xl mx-auto leading-relaxed">
                Our proven 6-step methodology ensures successful project delivery and exceptional results every time.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
              {processSteps.map((process, index) => (
                <motion.div
                  key={index}
                  variants={cardVariants}
                  className="relative group"
                  whileHover={{ scale: 1.05 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <div className="text-center relative">
                    <div className="relative inline-block mb-8">
                      <div className={`absolute inset-0 w-32 h-32 bg-gradient-to-r ${process.color} rounded-full blur-sm opacity-75 group-hover:opacity-100 transition-opacity duration-300`}></div>
                      <div className="relative w-28 h-28 bg-white rounded-full shadow-2xl flex items-center justify-center border-4 border-gray-100 group-hover:border-white transition-all duration-300">
                        <div className="text-4xl">{process.icon}</div>
                      </div>
                      <div className="absolute -top-2 -right-2 w-8 h-8 bg-slate-800 text-white rounded-full flex items-center justify-center text-sm font-bold shadow-lg">
                        {process.step}
                      </div>
                    </div>
                    <div className="space-y-4">
                      <h3 className="text-2xl font-bold text-slate-900 group-hover:text-blue-600 transition-colors duration-300">
                        {process.title}
                      </h3>
                      <p className="text-slate-600 leading-relaxed max-w-xs mx-auto">
                        {process.description}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 relative">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.5 }}
            variants={{
              hidden: { opacity: 0, scale: 0.95 },
              visible: { opacity: 1, scale: 1, transition: { duration: 1 } }
            }}
          >
            <div className="attractive-card p-20 shadow-2xl border-0 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-600/5 via-indigo-600/5 to-purple-600/5"></div>
              <div className="relative z-10">
                <h2 className="text-4xl md:text-6xl font-bold text-slate-900 mb-8">
                  Ready to Get Started?
                </h2>
                <p className="text-xl text-slate-700 mb-12 max-w-3xl mx-auto leading-relaxed">
                  Let's discuss your project requirements and create a custom solution
                  that meets your specific business needs and drives sustainable growth.
                </p>
                <div className="flex flex-col sm:flex-row gap-8 justify-center">
                  <Link to={createPageUrl("Contact")}>
                    <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      <Button size="lg" className="gradient-primary text-white hover:shadow-xl transition-all duration-300 hover:scale-105 px-12 py-6 text-xl rounded-2xl">
                        Start Your Project
                        <ArrowRight className="ml-3 h-7 w-7" />
                      </Button>
                    </motion.div>
                  </Link>
                  <Link to={createPageUrl("Portfolio")}>
                    <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      <Button variant="outline" size="lg" className="border-2 border-blue-300 text-blue-700 hover:bg-blue-50 hover:border-blue-400 transition-all duration-300 px-12 py-6 text-xl rounded-2xl">
                        View Our Work
                        <Star className="ml-3 h-7 w-7" />
                      </Button>
                    </motion.div>
                  </Link>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
